<?php require 'header.php';?>



      <div class="resim"></div>
      <h1 class="site-heading text-center text-white d-none d-lg-block">
          <span class="site-heading-upper text-primary mb-3">Web Dev.student</span>
          <span class="site-heading-lower">OLGUN KARABULUT</span>
      </h1>



      <nav class="social-media">
          <ul class="nav">
              <li><a href="https://discord.gg/5nphUDdWyV"  target="_blank"><i class="fab fa-discord"></i></a></li>
              <li><a href="https://www.linkedin.com/in/olgun-karabulut-46a11a182/"  target="_blank"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="https://twitter.com/OlgunDev" target="_blank"><i class="fa fa-twitter"></i></a></li>
              <li><a href="https://github.com/Blackcloud00" target="_blank"><i class="fa fa-github"></i></a></li>
              <li><a href="https://www.instagram.com/olgun.karabulut/" target="_blank"><i class="fa fa-instagram"></i></a></li>
          </ul>
      </nav>

  </div>

  <div class="area-2">
  <div class="baslik"><span>About</span></div>

  <section class="page-section clearfix">
    <div class="container">
      <div class="intro">
        <img class="intro-img img-fluid mb-3 mb-lg-0 rounded" src="img/2.jpg" alt="" >
        <div class="intro-text left-0 text-center bg-faded p-5 rounded">
          <h2 class="section-heading mb-4">
<!--            <span class="section-heading-upper">Fresh Coffee</span>-->
              <span class="section-heading-lower">Hakkımda</span>
          </h2>
            <p class="mb-3">Şöyle ufaktan biraz daha bahsedeyim kendimden; şu an lise mezunuyum, üniversiteye hazırlanıyorum, yazılım alanında bildiğim doğru ve yanlış olabilecek bir takım şeyler var...</p>          <div class="intro-button mx-auto">
          <a class="btn btn-primary btn-xl" href="about.php">Yazının Devamı...</a>
          </div>
        </div>
      </div>
    </div>


  </section>
      <?php require 'skill_bar.php';?>

  </div>



  <!--<section class="page-section cta">
    <div class="container">
      <div class="row">
        <div class="col-xl-9 mx-auto">
          <div class="cta-inner text-center rounded">
            <h2 class="section-heading mb-4">
              <span class="section-heading-upper">Our Promise</span>
              <span class="section-heading-lower">To You</span>
            </h2>
            <p class="mb-0">When you walk into our shop to start your day, we are dedicated to providing you with friendly service, a welcoming atmosphere, and above all else, excellent products made with the highest quality ingredients. If you are not satisfied, please let us know and we will do whatever we can to make things right!</p>
          </div>
        </div>
      </div>
    </div>
  </section>-->
  <?php require 'footer.php';?>
