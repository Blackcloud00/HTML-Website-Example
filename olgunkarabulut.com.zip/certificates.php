    <?php require 'header.php';?>
 <section class="page-section about-heading">
    <div class="container">
      <img class="img-fluid rounded about-heading-img mb-3 mb-lg-0" src="img/olgun_kim.jpg" alt="">
      <div class="about-heading-content">
        <div class="row">
          <div class="col-xl-9 col-lg-10 mx-auto">
            <div class="bg-faded rounded p-5">
              <h2 class="section-heading mb-4">
                <span class="section-heading-upper">OLGUN KARABULUT HAKKINDA</span>
                <span class="section-heading-lower">UFAK BİR BİLGİ</span>
              </h2>
              <p>Merhabalar, ben Olgun Karabulut,</p>
              <p class="mb-0">Şöyle ufaktan biraz daha bahsedeyim kendimden; şu an lise mezunuyum, üniversiteye hazırlanıyorum, yazılım alanında bildiğim doğru ve yanlış olabilecek bir takım şeyler var, yanlışlarımı daha iyi bir şekilde pekiştirip öğrenmeye çalışıyorum, şuan ufak projeler yapıp, freelance iş alıyorum. Şimdilik bu kadar :)</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <?php require 'footer.php';?>
