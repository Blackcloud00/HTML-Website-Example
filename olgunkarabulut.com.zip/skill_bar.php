
<style type="text/css">

    #circleBar{
        margin-top: 180px;
        text-align: center;
        color: white;
    }
    #circleBar .round{
        min-height: 255px;
        margin-top: 30px;
        position: relative;
        margin-bottom: 20px;
    }

    #circleBar .round strong{
        position: absolute;
        top: 50%;
        left: 50%;
        margin-top: -50px;
        transform: translate(-50%);
        font-size:40px;
        color: #ffffff;
        font-weight: 100;
    }

    #circleBar span{
        display: block;
        font-size: 17px;
        margin-top: 10px;
    }

    #circleBar span i{
        font-size: 22px;
        margin-right: 7px ;
    }
    section .btn{
        color: white !important;
    }

    section button:hover{
        border-color: white;
    }
</style>

<section id="circleBar">
    <h1>SKILLS</h1>

    <div class="container">
        <div class="row">

            <div class="col-md-3">
                <div class="round" data-value="0.85" data-size="200" data-thickness="12">
                    <strong></strong>
                    <span><i class="fa fa-html5"></i>
                    HTML-5
                    </span>
                </div>
            </div>

            <div class="col-md-3">
                <div class="round" data-value="0.60" data-size="200" data-thickness="12">
                    <strong></strong>
                    <span><i class="fa fa-css3"></i>
                    CSS-3
                    </span>
                </div>
            </div>


            <div class="col-md-3">
                <div class="round" data-value="0.30" data-size="200" data-thickness="12">
                    <strong></strong>
                        <span><i class="fab fa-js"></i>
                    JAVASCRİPT
                    </span>
                </div>
            </div>

            <div class="col-md-3">
                <div class="round" data-value="0.70" data-size="200" data-thickness="12">
                    <strong></strong>
                    <span><i class="fab fa-bootstrap"></i>
                    BOOTSTRAP
                    </span>
                </div>
            </div>



        </div>
    </div>
    <button class="btn" onclick=" Circlle('.round');">
        Refresh
    </button>
</section>




