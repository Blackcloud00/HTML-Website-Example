
<footer class="footer text-faded text-center py-5">
    <div class="container">
        <p class="m-0 small">Copyright &copy; Olgun Karabulut 2021</p>
    </div>
</footer>

<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


<script src="https://code.jquery.com/jquery-3.5.1.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-circle-progress/1.2.0/circle-progress.js"></script>



<script type="text/javascript">

    function Circlle(el) {
        $(el).circleProgress({fill: {color: '#ffffff'}})
            .on('circle-animation-progress', function (event, progress, stepValue) {
                $(this).find('strong').text(String(stepValue.toFixed(2)).substr(2)+'%');
            });
    }

    Circlle('.round');

</script>

</body>

</html>
