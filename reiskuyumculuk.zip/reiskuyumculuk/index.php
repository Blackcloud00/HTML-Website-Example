<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reis Kuyumculuk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/icon-font/css/reiskuyumculuk.css">
    <link rel="stylesheet" href="assets/owl/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/owl/owl.theme.default.min.css">

</head>
<body>
<header>
    <nav class="navbar ust-menu">
        <div class="text-1 justify-content-start">
            <span class="text-span-1">300 TL Üzeri Siparişlerde Ücretsiz Kargo</span>
        </div>
        <div class="icons-end-lang-dropdown justify-content-end">
            <span class="icon icon-user-o"></span>
            <span class="icon icon-heart-empty"></span>
            <span class="icon icon-diamond"></span>
            <div class="dropdown">
                <button class="dropbtn">Türkçe <span class="icon-angle-down"></span></button>
                <div class="dropdown-content">
                    <a href="#">Tr</a>
                    <a href="#">Eng</a>
                    <a href="#">Ar</a>
                </div>
            </div>
        </div>
    </nav>
    <div class="collapse" id="navbarToggleExternalContent">
        <div class="bg-dark p-4">
            <h5 class="text-white h4">İç menü</h5>
            <span class="text-muted">İç menü,İç menü,İç menü</span>
        </div>

    </div>
    <nav class="navbar ust-menu-2">
        <div class="container-fluid col-12">
            <button class="navbar-toggler justify-content-start " type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                <span class="icon-menu ust-menu-toggle"></span>
            </button>
            <div class="justify-content-center">
                <img class="img-logo" src="assets/img/logo.png" alt="Reis Kuyumculuk Logo">
            </div>
            <form class="d-flex justify-content-end">
                <span class="arama-cubugu-icon  icon-search"></span>
                <input class="arama-cubugu me-2" type="search" placeholder="Site içi ürün arama" aria-label="Search">
            </form>
        </div>
    </nav>
</header>
<div class="section-1">
    <div class="owl-carousel owl-theme slider" id="one">
        <div class="item slider-item item-1">
            <h1 class="slider-baslik">MODERN KOLEKSİYON</h1>
            <p class="slider-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris vestibulum, lacus
                at auctor volutpat, dui purus pulvinar massa, vel venenatis lectus sem et ugue.</p>
            <button type="button" class="btn koleksiyon-button">KOLEKSİYONU GÖRÜNTÜLE</button>
        </div>
        <div class="item slider-item item-1">
            <h1 class="slider-baslik">MODERN KOLEKSİYON</h1>
            <p class="slider-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris vestibulum, lacus
                at auctor volutpat, dui purus pulvinar massa, vel venenatis lectus sem et ugue.</p>
            <button type="button" class="btn koleksiyon-button">KOLEKSİYONU GÖRÜNTÜLE</button>
        </div>
        <div class="item slider-item item-1">
            <h1 class="slider-baslik">MODERN KOLEKSİYON</h1>
            <p class="slider-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris vestibulum, lacus
                at auctor volutpat, dui purus pulvinar massa, vel venenatis lectus sem et ugue.</p>
            <button type="button" class="btn koleksiyon-button">KOLEKSİYONU GÖRÜNTÜLE</button>
        </div>
        <div class="item slider-item item-1">
            <h1 class="slider-baslik">MODERN KOLEKSİYON</h1>
            <p class="slider-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris vestibulum, lacus
                at auctor volutpat, dui purus pulvinar massa, vel venenatis lectus sem et ugue.</p>
            <button type="button" class="btn koleksiyon-button">KOLEKSİYONU GÖRÜNTÜLE</button>
        </div>
    </div>
</div>
<div class="section-2">
    <div class="container-fluid">
        <h1 class="section-2-baslik">
            <div class="container"> İnce Ruhunuzu </br><span
                        class="section-2-farkli-baslik">Yansıtan Parıldayan</span> </br>Takılar.
            </div>
        </h1>

        <div class="container text-and-button ">
            <div class="row">
                <div class="left col-md-4 col-xs-12">
                    <h3 class="text-banner">Kendinizi </br> Yansıtın</h3>
                    <p class="text"><span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad animi, atque autem blanditiis consequatur dicta eaque eligendi eveniet fugiat hic laborum minus modi molestias nisi quam quia ratione unde voluptates.</span></br></br>
                        <span>Beatae consectetur consequuntur cumque illo incidunt, magni modi mollitia necessitatibus nesciunt nostrum quam quasi reiciendis rerum saepe soluta sunt vero? Culpa dolorem nostrum quibusdam sed tempore? Deleniti deserunt ducimus vitae!</span>
                    </p>
                    <button type="button" class="btn alisveris-button">ALIŞVERİŞE BAŞLA</button>
                </div>
                <div class="center col-md-4 "><img src="assets/img/R-0981.png" alt=""></div>
                <div class="right col-md-4 col-xs-12">
                    <div class="urun">
                        <h4 class="urun-baslik">Tek Taş Pırlanta</h4>
                        <p class="urun-text">Quisque sagittis diam sit amet elit placerat, sit amet iaculis purus
                            egestas. Quisque dapibus tur...</p>
                        <img class="urun-gorsel" src="assets/img/urun-1.png" alt="">
                        <p class="urun-fiyat">2,850 TL</p>
                    </div>
                    <div class="urun-1">
                        <h4 class="urun-baslik">Yaprak Desenli Taşlı Küpe</h4>
                        <p class="urun-text">Quisque sagittis diam sit amet elit placerat, sit amet iaculis purus
                            egestas. Quisque dapibus tur...</p>
                        <img class="urun-gorsel" src="assets/img/urun-2.png" alt="">
                        <p class="urun-fiyat">2,850 TL</p>
                    </div>
                    <div class="urun-1">
                        <h4 class="urun-baslik">Taşlı Alyans</h4>
                        <p class="urun-text">Quisque sagittis diam sit amet elit placerat, sit amet iaculis purus
                            egestas. Quisque dapibus tur...</p>
                        <img class="urun-gorsel" src="assets/img/urun-3.png" alt="">
                        <p class="urun-fiyat">2,850 TL</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="section-3">
    <div class="container">
        <h2 class="section-3-baslik">TÜM ÜRÜNLER <img src="assets/img/diamond.png" alt=""></h2>
        <ul class="slider-liste">
            <li><h4><b>ÖNE ÇIKANLAR</b></h4></li>
            <li><h4>YENİ ÜRÜNLER</h4></li>
            <li><h4>ÖN SATIŞTA OLANLAR</h4></li>
            <li><h4>İNDİRİMDEKİLER</h4></li>
        </ul>
        <div class="slider-2">
            <div class="owl-carousell owl-carousel owl-theme" id="two">
                <div class="item ucretsiz-kargo"><img src="assets/img/slider-2/Home-product-1.jpg" alt="">
                    <div class="name">Nam eget purus orci</div>
                    <div class="fiyat"><span class="non-fiyat"><del>3,850 TL</del></span> 2,850 TL</div>
                </div>
                <div class="item ucretsiz-kargo"><img src="assets/img/slider-2/Home-product-2.jpg" alt="">
                    <div class="name">Nam eget purus orci</div>
                    <div class="fiyat"><span class="non-fiyat"><del>3,850 TL</del></span> 2,850 TL</div>
                </div>
                <div class="item" style="top: 30px;position: relative;"><img
                            src="assets/img/slider-2/Home-Product-3.jpg" alt="">
                    <div class="name">Nam eget purus orci</div>
                    <div class="fiyat"><span class="non-fiyat"><del>3,850 TL</del></span> 2,850 TL</div>
                </div>
                <div class="item" style="top: 30px;position: relative;"><img
                            src="assets/img/slider-2/Home-product-4.jpg" alt="">
                    <div class="name">Nam eget purus orci</div>
                    <div class="fiyat"><span class="non-fiyat"><del>3,850 TL</del></span> 2,850 TL</div>
                </div>
                <div class="item ucretsiz-kargo"><img src="assets/img/slider-2/Home-product-5.jpg" alt="">
                    <div class="name">Nam eget purus orci</div>
                    <div class="fiyat"><span class="non-fiyat"><del>3,850 TL</del></span> 2,850 TL</div>
                </div>
                <div class="item" style="top: 30px;position: relative;"><img
                            src="assets/img/slider-2/Home-product-1.jpg" alt="">
                    <div class="name">Nam eget purus orci</div>
                    <div class="fiyat"><span class="non-fiyat"><del>3,850 TL</del></span> 2,850 TL</div>
                </div>
                <div class="item" style="top: 30px;position: relative;"><img
                            src="assets/img/slider-2/Home-product-2.jpg" alt="">
                    <div class="name">Nam eget purus orci</div>
                    <div class="fiyat"><span class="non-fiyat"><del>3,850 TL</del></span> 2,850 TL</div>
                </div>
            </div>
        </div>
    </div>

</div>
<div class="section-4">
    <div class="container-fluid alan">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-12 col-xs-12">
                    <h2 class="yazi-1"><span class="yazi-2"> Gerçek Güzellik </span></br> Seninle. </br> Onları İfade Et
                    </h2>
                    <p class="paragraph-2">Praesent consequat sit amet lorem condimentum tincidunt. Sed lobortis velit
                        sed mauris vulputate, quis eleifend erat luctus. Duis eget imperdiet massa. Praesent libero est,
                        laoreet in lorem eu, hendrerit tincidunt ante.</br> </br> Curabitur enim urna, facilisis id
                        ultrices a, lobortis vitae magna. Vestibulum varius feugiat massa, sed scelerisque metus gravida
                        vitae. Proin eget feugiat nibh.</br> </br> Lorem ipsum dolor sit amet, consectetur adipiscing
                        elit.

                    </p>
                </div>
                <div class="col-lg-7 col-md-12 col-xs-12 resimler">
                    <img class="resim-1" src="assets/img/section_4/2.jpg" alt="">
                    <img class="resim-2" src="assets/img/section_4/1.jpg" alt=""></br>
                    <img class="resim-3" src="assets/img/section_4/3.jpg" alt="">
                    <img class="resim-4" src="assets/img/section_4/4.jpg" alt="">
                    <img class="resim-5" src="assets/img/section_4/5.jpg" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<div class="section-5">
    <div class="container-fluid resimler justify-content-center">
        <div class="row">
            <div class="col-md-6 col-xs-12">
                <img class="resim-1" src="assets/img/section_5/1.jpg" alt="">
                <h2>onlari ifade et</h2>
            </div>

            <div class="hey col-md-3 col-xs-12">
                <img class="resim-2" src="assets/img/section_5/2.jpg" alt="">
                <button type="button" class="btn kesfet-button">ŞİMDİ KEŞFET</button>
            </div>
            <div class=" hey  col-md-3 col-xs-12">
                <img class="resim-3" src="assets/img/section_5/3.jpg" alt="">
                <button type="button" class="btn kesfet-button">ŞİMDİ KEŞFET</button>
            </div>
        </div>

    </div>
</div>
<div class="section-6">
    <div class="container-fluid resimler">
        <h2 class="section-6-baslik">INSTAGRAM FEED <img src="assets/img/diamond.png" alt=""></h2>
        <div class="row">
            <div class="col-12">
                <img src="assets/img/section-6/1.jpg" alt="">
                <img src="assets/img/section-6/2.jpg" alt="">
                <img src="assets/img/section-6/3.jpg" alt="">
                <img src="assets/img/section-6/4.jpg" alt="">
                <img src="assets/img/section-6/5.jpg" alt="">
            </div>
            <div class="col-12">
                <img src="assets/img/section-6/6.jpg" alt="">
                <img src="assets/img/section-6/7.jpg" alt="">
                <img src="assets/img/section-6/8.jpg" alt="">
                <img src="assets/img/section-6/9.jpg" alt="">
                <img src="assets/img/section-6/10.jpg" alt="">
            </div>
        </div>


    </div>
</div>
<div class="section-7">
    <div class="slider container">
        <h2 class="section-7-baslik">BLOG <img src="assets/img/diamond.png" alt=""></h2>
        <div class="owl-carousel owl-theme" id="three">
            <div class="item"><img src="assets/img/slider-3/2.jpg" alt=""></div>
            <div class="item"><img src="assets/img/slider-3/1.jpg" alt=""></div>
            <div class="item"><img src="assets/img/slider-3/3.jpg" alt=""></div>
        </div>
        <div class="text">
            <h3>Lorem ipsum dolor sit amet</h3>
            <p>Praesent consequat sit amet lorem condimentum tincidunt. Sed lobortis velit sed mauris vulputate, quis
                eleifend erat luctus. Duis eget imperdiet massa. Praesent libero est, laoreet in lorem eu, hendrerit
                tincidunt ante.</br></br>

                Curabitur enim urna, facilisis id ultrices a, lobortis vitae magna. Vesztibulum varius feugiat massa,
                sed scelerisque metus gravida vitae. Proin eget feugiat nibh.</br></br>

                Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </div>
    </div>
</div>
<div class="section-8">
    <div class="alan container-fluid">
        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-lg-4 col-md-12 alan-1">
                    <h3>Bültenimize abone olun</h3>
                    <p>Yeni ürünler ve yaklaşan satışlar hakkında
                        en son güncellemeleri alın.</p>
                </div>
                <div class="col-xl-6 col-lg-4 col-md-12 alan-2">
                    <input type="text" placeholder="e-posta adresini yazınız">
                    <span class="iconicmail icon-mail"></span>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-12 alan-3">
                    <span class="social-icon icon-facebook"></span>
                    <span class="social-icon icon-instagram"></span>
                    <span class="social-icon icon-youtube-play"></span>
                    <span class="social-icon icon-twitter"></span>
                    <span class="social-icon icon-pinterest"></span>
                    <span class="social-icon icon-linkedin"></span>
                </div>
            </div>
        </div>
    </div>
</div>
<footer>
    <div class="alan_footer container-fluid">
        <div class="container">
            <div class="row">
                <div class="footer_alt_1 col-lg-7 col-sm-12">
                    <img class="footer_img_1" src="assets/img/footer/2.png" alt="">
                    <img class="footer_img_2" src="assets/img/footer/1.png" alt="">
                </div>
                <div class="footer_alt_2 col-lg-5 col-sm-12">
                    <div class="text">
                        <p class="text_footer">
                            Herhangi bir sorunuz varsa bize ulaşın </br>
                            <span class="mail"><a
                                        href="mailto:info@reiskuyumculuk.com">info@reiskuyumculuk.com</a></span> </br>
                            <span class="tel"><a href="tel:08502551815">0850 255 18 15</a></span> </br>
                            Teşvikiye Caddesi Hak Pasajı No:22/44 Nişantaşı / İstanbul </br>
                            Pazartesi - Cuma: 09:00 - 18:00 </br>
                            Cumartesi: 10:00 - 14:00 </br>
                            <span class="telif_text">Copyright © 2020 Reis Kuyumculuk</span>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="dijital_net_logo" style="background-color: #1d1d1d;
    height: 40px;">
            <img style="float: right;" src="assets/img/dijitallnetLogo.png" alt="">
        </div>
    </div>
</footer>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"
        integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4"
        crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
        integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p"
        crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js"
        integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT"
        crossorigin="anonymous"></script>
<script src="assets/owl/owl.carousel.min.js"></script>
<script src="assets/js/main.js"></script>

</body>
</html>