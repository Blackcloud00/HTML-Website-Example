var one = $("#one");
var two = $("#two");
var three = $("#three");
one.owlCarousel({
    loop:true,
    margin:10,
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
            nav:true
        },
        600:{
            items:1,
            nav:false
        },
        1000:{
            items:1,
            nav:true,
            loop:false
        }
    }
})


two.owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:5
        }
    }
})


three.owlCarousel({
    autoplay: true,
    center: true,
    stagePadding: 50,
    margin:-80,
    autoplayTimeout:5000,
    items:3,
})