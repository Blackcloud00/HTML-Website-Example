<?php
$content = [
    [
        "img" => "neden-1.png",
        "h3" => "105 Ülkede 70.000’in Üzerinde Bahçeci Bebeği",
        "p" => "105 ülkede 70.000’den fazla bebeğimizle dünyanın en büyük ailelerinden biriyiz.",
    ],
    [
        "img" => "neden-2.png",
        "h3" => "Son teknolojiyle donatılmış embriyoloji laboratuvarı",
        "p" => "Gelişmiş embriyoloji laboratuvarımız ve 40’ın üzerinde embriyoloğumuzla hizmetinizdeyiz.",
    ],
    [
        "img" => "neden-3.png",
        "h3" => "105 Ülkede 70.000’in Üzerinde Bahçeci Bebeği",
        "p" => "Özellikle zor vakalarda, uluslararası standartların üzerinde başarı oranına sahibiz.",
    ],
    [
        "img" => "neden-4.png",
        "h3" => "Zor Vakaların Merkezi",
        "p" => "ERA, NGS, IMSI ve embriyoskop gibi başarı artıran teknolojiler sayesinde binlerce çiftin bebek hayalini gerçeğe dönüştürüyoruz.",
    ]
];
?>