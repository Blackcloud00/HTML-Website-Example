<?php defined('view') or die('<script>location.href="404"</script><META HTTP-EQUIV=REFRESH CONTENT="0; 404">'); ?>
<?php require 'banner/pay-genclik-kuruldu.php';?>
<?php require 'hakkimizda-short.php';?>
<?php require 'haberler-slider.php';?>
<?php require 'biz-kimiz-slider.php';?>




