<?php defined('view') or die('<script>location.href="404"</script><META HTTP-EQUIV=REFRESH CONTENT="0; 404">'); ?>
<div class="gtco-services gtco-section" style="padding-bottom: 8em;">
    <div class="gtco-container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 gtco-heading text-center" >
                <h2>PAY'daşlar</h2>
                <p>Farabi'nin "Hak, Liyakat, Pay" teorisinden aldığı ilhamla gençliğin dolayısıyla toplumun kalkınmasını hedefleyen, gençlerle iyiliği, güzelliği ve bilgiyi paylaşma da payına düşeni yapmaya çalışan profesyonellerin ortak bir paydada toplanarak kurduğu bir gençlik derneğidir.</p>
            </div>
        </div>
        <div class="row">

            <div class="col-md-12">
                <div class="owl-carousel owl-carousel-carousel">

                    <?php foreach ($person as $k => $item): ?>
                        <div class="item">
                            <div class="gtco-staff">
                                <img src="images/person/<?= $item["img-slide"] ?>" alt="" class="img-responsive"
                                     style="border-radius: 25px;">
                                <h2><?= $item["name"] ?></h2>
                                <p class="role"><?= $item["role"] ?></p>
                                <p><?= $item["des-sum"] ?>
                                    <a href="biz-kimiz.php#<?= $item["id"] ?>" style="text-decoration: underline;">
                                        devamı...</a></p>
                                <ul class="fh5co-social">
                                    <?php foreach ($item["social"] as $key => $social): ?>
                                        <li><a href="<?= $social["link"] ?>" target="_blank"><i
                                                        class="icon-<?= $social["sname"] ?>"></i></a></li>
                                    <?php endforeach; ?>
                                    <a href="mailto:<?= $item["mail"] ?>" style="position: absolute; right: 50px;"><span style="font-size: 20px;"><i style="position: relative;top: 3px;" class="icon-mail"></i> MAIL</span></a>
                                </ul>
                            </div>
                        </div>
                    <?php endforeach; ?>

                </div>
            </div>

        </div>
    </div>
</div>