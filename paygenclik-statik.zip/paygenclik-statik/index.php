<?php
define("view","security");

require 'header.php';

require 'anasayfa.php';

require  'footer.php';

?>