<?php
define("view","security");
require 'header.php';

?>


        <div class="gtco-services gtco-section">
            <div class="gtco-container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2 gtco-heading text-center" style="padding-bottom: 9em; padding-top: 3em;">
                        <h2>PAY'daşlar</h2>
                        <p>PAY Gençlik, paylaşmayı yaşamın merkezine alan, paylaşmanın ve ortak hareket etmenin gücüne inanan, Farabi'nin "Hak, Liyakat, Pay" teorisinden aldığı ilhamla gençliğin dolayısıyla toplumun kalkınmasını hedefleyen, gençlerle iyiliği, güzelliği ve bilgiyi paylaşma da payına düşeni yapmaya çalışan profesyonellerin ortak bir paydada toplanarak kurduğu bir gençlik derneğidir.</p>
                    </div>
                </div>
                <?php foreach ($person as $k => $item): ?>
                <div class="row" style="padding-bottom: 7em;">
                    <div class="duygu_naz col-lg-12 col-md-12   gtco-heading gtco-staff" id="<?=$item["id"]?>">
                        <h2><?=$item["name"]?> </h2>
                        <ul class="fh5co-social" style="position:relative; top: 10px; left: 60px;">
                            <?php foreach ($item["social"] as $key => $social): ?>
                            <li><a href="<?=$social["link"]?>" target="_blank"><i class="icon-<?=$social["sname"]?>"></i></a></li>
                            <?php endforeach;?>
                        </ul>
                        <div class="img col-lg-3 col-md-4 col-sm-4 ">
                          <img src="<?=URL?>/images/person/<?=$item["img"]?>" alt="" width="200" height="auto" style="border-radius: 40px; position: relative; top: 50px; left: 40px">

                      </div>
                      <div class="col-lg-9 col-md-8 col-sm-8 about-text">
                          <p style="font-size: 15px;"><?=$item["des"]?></p>
                          <a href="mailto:<?=$item["mail"]?>"><span style="font-size: 35px;"><i style="position: relative;top: 3px;" class="icon-mail"></i> MAIL</span></a>
                      </div>

                    </div>

                </div>
                 <?php endforeach; ?>
            </div>
        </div>


<?php require 'footer.php'; ?>