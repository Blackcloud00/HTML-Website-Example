<?php defined('view') or die('<script>location.href="404"</script><META HTTP-EQUIV=REFRESH CONTENT="0; 404">');
?>
<header id="gtco-header" class="gtco-cover" role="banner">
    <div class="gtco-container">
        <div class="row">
            <div class="col-xs-12 col-md-12 col-lg-12 col-sm-12 col-md-offset-0 text-left">
                <div class="display-t">
                    <div class="display-tc">
                        <div class="row">
                            <div class="col-sm-5  col-md-6 col-lg-5  header-img" style="padding-left: 0;">
                                <img src="<?=URL?>/images/banner/p-human-5-img.png"  class="p-image-1" alt="p-img">
                            </div>
                            <div class="col-xs-12  col-sm-7  col-md-6 col-lg-7 copy textro">
                                <img src="<?=URL?>/images/banner/text-2.png" class="text-2" alt="">
                                <div class="textt" style="position: relative; top: 35px;">
                                    <p class="textir"><b>Pay</b>laşmak tanıdığımız en samimi eylem.<br/> <b>Pay</b>laşmanın kökü ise <b>Pay</b>'dır.<br/>
                                        <b>Pay</b> olmadan <b>pay</b>laşmak var olmaz.<br/> İşte bu küçücük kelimenin
                                        ardındaki <br/> bilgelik ve derinlik <b>bizim hikayemizi oluşturuyor.</b></p>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>