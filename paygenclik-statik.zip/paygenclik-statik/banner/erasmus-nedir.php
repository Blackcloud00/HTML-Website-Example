<?php defined('view') or die('<script>location.href="404"</script><META HTTP-EQUIV=REFRESH CONTENT="0; 404">');
?>
<header id="gtco-header" class="gtco-cover" role="banner">
    <div class="gtco-container">
        <div class="row">
            <div class="col-xs-12 col-md-12 col-lg-12 col-sm-12 col-md-offset-0 text-left">
                <div class="display-t">
                    <div class="display-tc">
                        <div class="row">
                            <div class="col-sm-5  col-md-6 col-lg-5  header-img" style="padding-left: 0;">
                                <img src="<?=URL?>/images/banner/proje_gezgini.jpg"  class="p-image-1" alt="p-img">
                            </div>
                            <div class="col-xs-12  col-sm-7  col-md-6 col-lg-7 copy textro">
                               <h1>ÜCRETSİZ yurt dışı fırsatları</h1>
                                <div class="textt" style="position: relative; top: 35px;">
                                    <p class="textir">Evet evet doğru okudunuz, ‘ÜCRETSİZ’ yurt dışı fırsatları.</br>Bu projelere kimler ve nasıl katılabilir?</br>Erasmus+ nedir?
                                       </br></br>  <a href="haberler/erasmus-nedir.php" class="haber-button">HABERİN DEVAMI</a></p>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>