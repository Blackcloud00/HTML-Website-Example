<?php
define("view","security");
require 'header.php';
require 'inc/news_db.php';

?>
        <div class="gtco-services gtco-section">
            <div class="gtco-container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2 gtco-heading text-left" style="padding-bottom: 4em; padding-top: 3em;">
                        <h2>Haberler</h2>
                        <p>Pay Gençlik Derneği ile ilgili haberlere ve duyurulara buradan erişebilirsiniz</p>
                    </div>
                </div>

                <?php foreach ($news as $key => $items): ?>
                <div class="row" style="padding-bottom: 1em;">
                    <div class=" col-lg-12 col-md-12 gtco-heading gtco-staff" id="1">
                        <h2><?=$items["title"]?></h2>
                        <ul class="fh5co-social" style="position:relative; bottom:10px; left: 60px;">
                            <li><h4 style="color: #8e9093;"><?= date("d.m.Y", strtotime($items["date"]));?></h4></li>
                        </ul>
                        <div class="img col-lg-5 col-md-6 col-sm-4 ">
                          <img class="klaus" src="<?=URL?>/images/haber/<?=$items["img"]?>" alt="">

                      </div>
                      <div class="col-lg-7 col-md-6 col-sm-8 about-text">
                          <p style="font-size: 20px;"><?=$items["des_sum"]?><a href="<?=URL?>/haberler/<?=$items["files_name"]?>.php" style="color:#1b6d85; text-decoration: underline;">  DEVAMI...</a></p>
                      </div>

                    </div>

                </div>
                <?php endforeach; ?>
            </div>
        </div>


<?php require 'footer.php'; ?>