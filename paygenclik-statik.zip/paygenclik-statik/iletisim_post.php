<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/phpmailer/phpmailer/src/Exception.php';
require 'vendor/phpmailer/phpmailer/src/PHPMailer.php';
require 'vendor/phpmailer/phpmailer/src/SMTP.php';

require 'inc/config.php';
;
if ($_POST){
    $adi_soyadi = $_POST['adi_soyadi'];
    $email = $_POST['email'];
    $telefon = $_POST['telefon'];
    $mesaj = $_POST['mesaj'];

 //  DB::insert("INSERT INTO iletisim(adi_soyadi,telefon,email,mesaj) VALUES(?,?,?,?)", array(
    //  $adi_soyadi,
   //  $telefon,
   //   $email,
 //     $mesaj,
 //  ));

    $mail_icerik = "Merhaba yönetici sitenizden yeni bir iletişim formu gönderildi. Bilgileri aşağıdadır.";
    $mail_icerik .= "<br/>"."Adı Soyadı:" .$adi_soyadi."<br/>";
    $mail_icerik .= "Telefon:" .$telefon."<br/>";
    $mail_icerik .= "Email:" .$email."<br/>";
    $mail_icerik .= "Mesaj:" .$mesaj."<br/>";

//    function secure ($var){
//        return stripslashes(htmlspecialchars($var));
//    }
//
//    $mail_icerik = secure($mail_icerik);

//Load Composer's autoloader
    require 'vendor/autoload.php';

//Instantiation and passing `true` enables exceptions
    $mail = new PHPMailer(true);

    try {
        //Server settings
        $mail->SMTPDebug = 0;                      //Enable verbose debug output
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'mail.paygenclikdernegi.org';                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = '_mainaccount@paygenclikdernegi.org';                     //SMTP username
        $mail->Password   = 'PAY*2424.';                               //SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         //Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
        $mail->Port       = 587;                                    //TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

        //Recipients
        $mail->setFrom('olgun.karabulut@paygenclikdernegi.org', 'PAY GENÇLİK DERNEĞİ WEBSİTE');
        $mail->addAddress('olguntube@gmail.com', 'Olgunos');



        //Content
        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';
        $mail->Subject = 'WEB SİTESİNDEN MESAJ VAR';
        $mail->Body    = $mail_icerik;
        $mail->AltBody = $mail_icerik;

        $mail->send();
        echo 'Message has been sent';
    } catch (Exception $e) {
        header("Location:iletisim.php?failed=1");
    }

    header("Location:iletisim.php?success=1");
}else{
    header("Location:iletisim.php?failed=1");
}
