<?php defined('view') or die('<script>location.href="404"</script><META HTTP-EQUIV=REFRESH CONTENT="0; 404">');
require 'inc/person_db.php';
define('URL', 'http://localhost/paygenclik-statik');

?>

<!DOCTYPE HTML>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="Paygençlik Derneği || PAY' ımıza düşeni yapıyoruz">
    <meta content="dernekler, gençlik dernekleri, erasmus gençlik dernekleri, erasmus dernekleri, erasmus+, yu "
          name="keywords">
    <meta name="author" content="Olgun Karabulut || https://www.olgunkarabulut.com">
    <meta name="copyright" content="Pay Gençlik Derneği">
    <title>PAY Gençlik Derneği</title>
    <!-- Favicons -->
    <link href="images/logo/favicon.png" rel="icon">
    <link href="images/logo/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Facebook and Twitter integration -->
    <meta property="og:title" content=""/>
    <meta property="og:image" content=""/>
    <meta property="og:url" content=""/>
    <meta property="og:site_name" content=""/>
    <meta property="og:description" content=""/>
    <meta name="twitter:title" content=""/>
    <meta name="twitter:image" content=""/>
    <meta name="twitter:url" content=""/>
    <meta name="twitter:card" content=""/>

    <link href="https://fonts.googleapis.com/css?family=Raleway:100,300,400,700" rel="stylesheet">

    <!-- Animate.css -->
    <link rel="stylesheet" href="css/animate.css">
    <!-- Icomoon Icon Fonts-->
    <link rel="stylesheet" href="css/icomoon.css">
    <!-- Themify Icons-->
    <link rel="stylesheet" href="css/themify-icons.css">
    <!-- Bootstrap  -->
    <link rel="stylesheet" href="css/bootstrap.css">

    <!-- Magnific Popup -->
    <link rel="stylesheet" href="css/magnific-popup.css">

    <!-- Owl Carousel  -->
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script&display=swap" rel="stylesheet">
    <!-- Theme style  -->
    <link rel="stylesheet" href="css/style.css">

    <!-- Modernizr JS -->
    <script src="js/modernizr-2.6.2.min.js"></script>
    <!-- FOR IE9 below -->
    <!--[if lt IE 9]>
    <script src="js/respond.min.js"></script>
    <![endif]-->

</head>
<body>

<div class="gtco-loader"></div>

<div id="page">

    <nav class="gtco-nav" role="navigation">
        <div class="gtco-container">

            <div class="row">
                <div class="col-sm-2 col-xs-12">
                    <div id="gtco-logo"><a href="<?=URL?>/index.php"><img src="<?=URL?>/images/logo/logo.png" width="200"
                                                                      height="100" alt="PAY GENÇLİK LOGO"></a></div>
                </div>
                <div class="col-xs-10 text-right menu-1">
                    <ul>
                        <li><a href="<?=URL?>/index.php">ANASAYFA</a></li>
                        <li class="has-dropdown">
                            <a href="<?=URL?>/hakkimizda.php">HAKKIMIZDA</a>
                            <ul class="dropdown">
                                <li><a href="<?=URL?>/biz-kimiz.php">BİZ KİMİZ?</a></li>
                            </ul>
                        </li>
                        <li class="has-dropdown">
                            <a href="#">BİLGİLENDİRME</a>
                            <ul class="dropdown">
                                <li><a href="<?=URL?>/logo-kullanim-kilavuzu.php">LOGO KULLANIM KILAVUZU</a></li>
                            </ul>
                        </li>
                        <li><a href="<?=URL?>/haberler.php">HABER & DUYURULAR</a></li>
                        <li><a href="<?=URL?>/iletisim.php">İLETİŞİM</a></li>
                    </ul>
                </div>
            </div>

        </div>
    </nav>

