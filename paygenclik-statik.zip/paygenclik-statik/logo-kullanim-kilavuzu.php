<?php
define("view","security");
require 'header.php';
?>
<header id="gtco-header" class="gtco-cover gtco-cover-xs gtco-inner" role="banner">
			<div class="gtco-container">
				<div class="row">
					<div class="col-md-12 col-md-offset-0 text-left">
						<div class="display-t">
							<div class="display-tc">
								<div class="row">
									<div class="col-md-8">
										<h1 class="no-margin">Logo Kullanım Kılavuzu</h1>
                                        <a class="sad" style="position: relative; font-size: 25px; top:40px;" href="documents/Logo-Kullanim-Kilavuzu.pdf" target="_blank"><i class="ti-layout-tab "></i> Pay Gençlik Derneği Logo Kullanım Kılavuzu</a></br>
                                        <a class="sad" style="position: relative; font-size: 25px; top:40px;" href="documents/Pay_Genclik_Dernegi_Logo_Paket.zip" target="_blank" download><i class="ti-layout-tab "></i> Pay Gençlik Derneği Logo Paketi</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>



<?php
require 'footer.php';
?>