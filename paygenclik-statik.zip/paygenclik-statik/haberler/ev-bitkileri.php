<?php
define("view","security");
require 'static/header.php';
require '../inc/news_db.php';

?>
        <div class="gtco-services gtco-section">
            <div class="gtco-container">
                <div class="row" style="padding-bottom: 1em;">
                    <div class="col-lg-12 col-md-12   gtco-heading gtco-staff" id="1">
                        <h2>Ev Bitkilerinin Bakımı</h2>
                        <ul class="fh5co-social" style="position:relative; bottom:10px; left: 60px;">
                            <li><a href="#" target="_blank">08.05.2021</a></li>
                        </ul>
                        <div class="img col-lg-5 col-md-6 col-sm-4 ">
                          <img class="klaus" src="<?=URL?>/images/haber/ev-bitklileri.jpg" alt="" width="400" height="auto" style="border-radius: 40px; position: relative; border: aquamarine 2px solid; left: 40px">

                      </div>
                      <div class="col-lg-7 col-md-6 col-sm-8 about-text">
                          <p style="font-size: 20px;">Yazın kendini iyice hissettirmesiyle, yeşilliğin içinde kaybolmak, çimenlere uzanıp gökyüzünü izlemek, tüm çiçekleri koklamak istediğimiz bu süreçlerde evde ilkbahar esintileri yaşamamız mümkün. Nasıl mı? Elbette evde bitki yetiştirmeye başlayarak! </br></br>Belki evinizde bitkiler var ama onları daha sağlıklı büyütmeyi sağlayacak bilgiler arıyorsunuz; belki de özellikle pandemi sürecinde bitki bakımıyla ilgilenmeye başladınız ama onlara nasıl bakacağınız konusunda daha fazla bilgi edinmek istiyorsunuz. İşte bu etkinliğimizde bitkilerin dilini çok iyi bilen
                              <a href="https://www.instagram.com/melisaaltinordu/" target="_blank" style="color: #00b3ee; font-weight: bold;">@melisaaltinordu</a>
                              <a href="https://www.instagram.com/melsworld_tr/" target="_blank" style="color: #00b3ee; font-weight: bold;">@melsworld_tr</a> bizlerle evde sağlıklı bir şekilde bitki yetiştirmek için ihtiyaç duyabileceğimiz tüm ipuçlarını paylaşacak.
                              </br> <span>📅 8 Mayıs 2021</span></br>
                              <span>⏰ 21:00⠀</span></br>
                              <a href="https://docs.google.com/forms/d/e/1FAIpQLScp43IFqkxw52mg2T6xPAM4WVkkgb8UXEmaCNo27ZFqti6oVA/viewform" style="color: #00b3ee; font-weight: bold;" target="_blank"><span>📜 Katılım Formu</span></a>
                          </p>
                      </div>

                    </div>

                </div>

            </div>
        </div>


<?php require 'static/footer.php'; ?>