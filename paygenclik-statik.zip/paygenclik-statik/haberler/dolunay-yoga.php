<?php
define("view", "security");
require 'static/header.php';
require '../inc/news_db.php';

?>
    <div class="gtco-services gtco-section">
        <div class="gtco-container">
            <div class="row" style="padding-bottom: 1em;">
                <div class="col-lg-12 col-md-12   gtco-heading gtco-staff" id="1">
                    <h2>Dolunay Yogasına Var Mısın?</h2>
                    <ul class="fh5co-social" style="position:relative; bottom:10px; left: 60px;">
                        <li><a href="#" target="_blank">26.05.2021</a></li>
                    </ul>
                    <div class="img col-lg-5 col-md-6 col-sm-4 ">
                        <img class="klaus" src="<?= URL ?>/images/haber/dolunay-yoga.jpg" alt="" width="400"
                             height="auto"
                             style="border-radius: 40px; position: relative; border: aquamarine 2px solid; left: 40px">

                    </div>
                    <div class="col-lg-7 col-md-6 col-sm-8 about-text">
                        <p style="font-size: 20px;">Dolunaylar içimizde birikenleri temizleme zamanıdır. Ve dolunayla
                            birlikte ay tutulmasıda aynı zamana denk geldi. Ay tutulması dönemlerinde gergin ve sinirli
                            olabiliriz.</br> </br>Bu kadar üst üste doğa olayları bize ruhumuzu ve bedenimizi dinlendirmemizi
                            söylüyorsa haydi durmayalım ne dersin?</br> </br>Zeynep Can Çermeli Aslan eşliğinde yoga
                            etkinliğimizde buluşalım.</br>
                            <span>📅 26 Mayıs 2021</span></br>
                            <span>⏰ 20:00⠀</span></br>
                            <span>💻 Zoom</span></br>
                            <a href="https://docs.google.com/forms/d/1pfu__yq38gcrk2hsFnUHTfyCDp9t8pEVNgOtB5FC3us/closedform" style="color: #00b3ee; font-weight: bold;" target="_blank"><span>📜 Katılım Formu</span></a>
                        </p>
                    </div>

                </div>

            </div>

        </div>
    </div>


<?php require 'static/footer.php'; ?>