<?php
define("view","security");
require 'static/header.php';
require '../inc/news_db.php';

?>
        <div class="gtco-services gtco-section">
            <div class="gtco-container">
                <div class="row" style="padding-bottom: 1em;">
                    <div class="col-lg-12 col-md-12   gtco-heading gtco-staff" id="1">
                        <h2>Gelin Tanış Olalım</h2>
                        <ul class="fh5co-social" style="position:relative; bottom:10px; left: 60px;">
                            <li><a href="#" target="_blank">03.05.2021</a></li>
                        </ul>
                        <div class="img col-lg-5 col-md-6 col-sm-4 ">
                          <img src="<?=URL?>/images/haber/tanis.jpg" alt="" width="400" height="auto" style="border-radius: 40px; position: relative; border: aquamarine 2px solid; left: 40px">

                      </div>
                      <div class="col-lg-7 col-md-6 col-sm-8 about-text">
                          <p style="font-size: 20px;">3 Mayıs Pazartesi günü 21:00’de PAY Gençlik Derneği Tanışma Toplantısında buluşuyoruz! </br></br> COVID-19 sürecinde sizlerle ekranlardan da olsa yüz yüze tanışmak, derneğimizle ilgili sorularınızı yanıtlamak ve önerilerinizi dinlemek istiyoruz.⠀</br></br>Derneğin gündeminde ve yakın gelecekte neler var gelin hep birlikte konuşalım. </br></br>PAYıma düşeni YAPmak istiyorum ve sizinle tanış olmak istiyorum diyen PAYdaşlarımızı bekliyoruz!
                              <a style="color: #1b6d85; text-decoration: underline;" href="https://docs.google.com/forms/d/e/1FAIpQLScBcldOCWQxTTef0iVsxpgTdW5NMUQ6PrxFFCisoUBkX-MPDA/viewform" target="_blank">KAYIT FORMU</a></p>
                      </div>

                    </div>

                </div>

            </div>
        </div>


<?php require 'static/footer.php'; ?>