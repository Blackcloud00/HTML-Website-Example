<?php
define("view","security");
require 'static/header.php';
require '../inc/news_db.php';

?>
        <div class="gtco-services gtco-section">
            <div class="gtco-container">
                <div class="row" style="padding-bottom: 1em;">
                    <div class="col-lg-12 col-md-12   gtco-heading gtco-staff" id="1">
                        <h2>Pay Gençlik Derneği Kuruldu</h2>
                        <ul class="fh5co-social" style="position:relative; bottom:10px; left: 60px;">
                            <li><a href="#" target="_blank">03.05.2021</a></li>
                        </ul>
                        <div class="img col-lg-5 col-md-6 col-sm-4 ">
                          <img class="klaus" src="<?=URL?>/images/haber/pay-genclik-dernegi-kuruldu.jpg" alt="" width="400" height="auto" style="border-radius: 40px; position: relative; border: aquamarine 2px solid; left: 40px">

                      </div>
                      <div class="col-lg-7 col-md-6 col-sm-8 about-text">
                          <p style="font-size: 20px;">Paylaşmayı seven, doğaya ve hayata karşı duyarlı olan tüm gençlerin birbirleri ile her konuda paylaşımlar yaparak karşılıklı bir şeyler katması için el ele verip Pay Gençlik Derneğini kurduk.</br></br>
                              Derneğimizin asıl amacı ise Türkiye’nin hatta dünyanın her noktasından gençlerin birbirleri ile iletişime geçmesini sağlamak. Bizler iletişim köprüsü olarak tüm gençleri ortak bir payda da buluşturmak istedik.</br></br>
                              Pay Gençlikte buluşup neler yapabiliriz?
                              Pay Gençlikte bir şeyleri öğrenmek kadar eğlenmek ve gençlere kaliteli vakit sunmak bizim en önemli kriterimiz. Her ay seminerlerimiz, film gecelerimiz, ayın kitap önerileri veya gençlerin içinde bulunup eğlenebileceği etkinlikler düzenliyoruz.</br></br>
                              Pay Gençlik Üyesi Olmanın Avantajları
                              Derneğimiz sizlerle birlikte kendini de her geçen gün geliştirmeye çalışmaktadır. Sizlerle birlikte emekleyip, yürüyüp koşmayı amaçlayan derneğimiz; gençlere ortak paydaların sınırsız olduğunu ve paylaşmanın hayatınıza, kendinize ne gibi özellikler katabileceğinizi sunmaktadır.</br></br>
                              Pay Gençlik Size Her Zaman Bir Adım Uzak
                              Derneğimiz gençler için her zaman her koşulda faaliyetlerini sunmaya hazırdır. Bütün sosyal medya platformlarından bir tıkla bize ulaşabilirsiniz. Bizler gençlerin kendini özgür ve çalışkan ruhlarıyla her zaman yanındayız.</br></br>

                              Atatürk’ün bir sözünü sizlere hatırlatmak isteriz.
                              “Biz her şeyi gençliğe bırakacağız... Geleceğin ümidi, ışıklı çiçekleri onlardır. Bütün ümidim gençliktedir.”
                          </p>
                      </div>

                    </div>

                </div>

            </div>
        </div>


<?php require 'static/footer.php'; ?>