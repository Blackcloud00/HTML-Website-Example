<?php defined('view') or die('<script>location.href="404"</script><META HTTP-EQUIV=REFRESH CONTENT="0; 404">'); ?>

<footer id="gtco-footer" class="gtco-section" role="contentinfo">
    <div class="gtco-container">
        <div class="row row-pb-md">
            <div class="col-md-8 gtco-footer-link">
                <div class="row">
                    <div class="col-md-7 text-center">
                        <ul class="gtco-list-link">
                            <li><a href="<?=URL?>/index.php">ANASAYFA</a></li>
                            <li><a href="<?=URL?>/hakkimizda.php">HAKKIMIZDA</a></li>
                            <li><a href="<?=URL?>/biz-kimiz.php">BİZ KİMİZ?</a></li>
                            <li><a href="<?=URL?>/haberler.php">HABER & DUYURULAR</a></li>
                            <li><a href="<?=URL?>/iletisim.php">İLETİŞİM</a></li>
                        </ul>
                    </div>
                    <div class="col-md-5 text-center ">
                        <ul class="fh5co-social">
                            <li class="social_li"><a href="https://www.facebook.com/paygenclikdernegi/" target="_blank"><i class="icon-facebook"></i></a></li>
                            <li class="social_li"><a href="https://www.instagram.com/paygenclikdernegi" target="_blank"><i class="icon-instagram"></i></a></li>
                            <li class="social_li"><a href="https://twitter.com/paygencder" target="_blank"><i class="icon-twitter"></i></a></li>
                            <li class="social_li"><a href="#" target="_blank"><i class="icon-linkedin"></i></a></li>
                        </ul>
                        <p>
                            <a href="mailto:iletisim@paygenclikdernegi.org">iletisim@paygenclikdernegi.org</a></br>
                       <small>Ankara/Türkiye</small>

                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 gtco-footer-subscribe text-center">
                <p><a href="iletisim.php" class="btn btn-white btn-outline">İLETİŞİME GEÇİN</a></p>
            </div>
        </div>
    </div>
    <div class="gtco-copyright">
        <div class="gtco-container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <p><small>&copy; 2021 Pay Gençlik Derneği Tüm Hakları Saklıdır. </small></p>
                </div>
            </div>
        </div>
    </div>
</footer>

</div>

<div class="gototop js-top">
    <a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
</div>

<!-- jQuery -->
<script src="../js/jquery.min.js"></script>
<!-- jQuery Easing -->
<script src="../js/jquery.easing.1.3.js"></script>
<!-- Bootstrap -->
<script src="../js/bootstrap.min.js"></script>
<!-- Waypoints -->
<script src="../js/jquery.waypoints.min.js"></script>
<!-- Carousel -->
<script src="../js/owl.carousel.min.js"></script>
<!-- Magnific Popup -->
<script src="../js/jquery.magnific-popup.min.js"></script>
<script src="../js/magnific-popup-options.js"></script>
<!-- Main -->
<script src="../js/main.js"></script>



</body>
</html>

