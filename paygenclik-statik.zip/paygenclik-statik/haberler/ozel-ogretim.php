<?php
define("view","security");
require 'static/header.php';
require '../inc/news_db.php';

?>
        <div class="gtco-services gtco-section">
            <div class="gtco-container">
                <div class="row" style="padding-bottom: 1em;">
                    <div class="col-lg-12 col-md-12   gtco-heading gtco-staff" id="1">
                        <h2>Kan Bağışı ile İlgili Her Şey</h2>
                        <ul class="fh5co-social" style="position:relative; bottom:10px; left: 60px;">
                            <li><a href="#" target="_blank">11.05.2021</a></li>
                        </ul>
                        <div class="img col-lg-5 col-md-6 col-sm-4 ">
                          <img class="klaus" src="<?=URL?>/images/haber/ozel-ogretim.jpg" alt="" width="400" height="auto" style="border-radius: 40px; position: relative; border: aquamarine 2px solid; left: 40px">

                      </div>
                      <div class="col-lg-7 col-md-6 col-sm-8 about-text">
                          <p style="font-size: 20px;">Kapsayıcı eğitim anlayışını daha önce duymuş muydunuz? </br></br> Yalnızca eğitimcileri, öğrencileri değil toplumdaki her bireyi ilgilendiren oldukça önemli bir yaklaşım. </br></br> Çünkü ‘Yaşamda Birlikteyiz’</br></br>  Gelin bu etkinliğimizde kapsayıcı eğitim anlayışına dair her şeyi Dr.Betül YILMAZ ile konuşalım.</br>
                              </br> <span>📅 16 Mayıs 2021</span></br>
                              <span>⏰ 20:00⠀</span></br>
                              <span>💻 Zoom</span></br>
                              <a href="https://docs.google.com/forms/d/e/1FAIpQLSf-Qogm7qrpeq-dthHo9cd4xrg8Od7tPt1i5aS0mMqvj5kMgg/viewform" style="color: #00b3ee; font-weight: bold;" target="_blank"><span>📜 Katılım Formu</span></a>
                          </p>
                      </div>

                    </div>

                </div>

            </div>
        </div>


<?php require 'static/footer.php'; ?>