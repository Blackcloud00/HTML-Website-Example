<?php
define("view","security");
require 'static/header.php';
require '../inc/news_db.php';

?>
        <div class="gtco-services gtco-section">
            <div class="gtco-container">
                <div class="row" style="padding-bottom: 1em;">
                    <div class="col-lg-12 col-md-12   gtco-heading gtco-staff" id="1">
                        <h2>19 Mayıs 2021</h2>
                        <ul class="fh5co-social" style="position:relative; bottom:10px; left: 60px;">
                            <li><a href="#" target="_blank">19.05.2021</a></li>
                        </ul>
                        <div class="img col-lg-5 col-md-6 col-sm-4 ">
                            <img class="klaus" src="<?=URL?>/images/haber/19-mayis-2021.jpg" alt="" width="400" height="auto" style="border-radius: 40px; position: relative; border: aquamarine 2px solid; left: 40px">

                      </div>
                        <div class="col-lg-7 col-md-6 col-sm-8 about-text">
                            <p style="font-size: 20px;">19 Mayıs güven, sevinç, hareket günüdür. Atatürk'ü Anma Gençlik ve Spor Bayramımız kutlu olsun.</p>
                        </div>

                    </div>

                </div>

            </div>
        </div>


<?php require 'static/footer.php'; ?>