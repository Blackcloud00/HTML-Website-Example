<?php
define("view","security");
require 'static/header.php';
require '../inc/news_db.php';

?>
        <div class="gtco-services gtco-section">
            <div class="gtco-container">
                <div class="row" style="padding-bottom: 1em;">
                    <div class="col-lg-12 col-md-12   gtco-heading gtco-staff" id="1">
                        <h2>Kan Bağışı ile İlgili Her Şey</h2>
                        <ul class="fh5co-social" style="position:relative; bottom:10px; left: 60px;">
                            <li><a href="#" target="_blank">11.05.2021</a></li>
                        </ul>
                        <div class="img col-lg-5 col-md-6 col-sm-4 ">
                          <img class="klaus" src="<?=URL?>/images/haber/kizilay-kan-haftasi.jpg" alt="" width="400" height="auto" style="border-radius: 40px; position: relative; border: aquamarine 2px solid; left: 40px">

                      </div>
                      <div class="col-lg-7 col-md-6 col-sm-8 about-text">
                          <p style="font-size: 20px;">Ülkemizde her yıl 6-12 Mayıs tarihleri Türk Kızılayı tarafından “Kızılay Kan Haftası” olarak kutlanıyor. </br></br> Kan, yapay olarak üretilmesi mümkün olmayan bir dokudur ve tek kaynağı diğer sağlıklı insanlardır. </br></br> Bu nedenle kan bağışı toplumsal bir sorumluluk ve bu konuda hepimizin PAYına düşenler var. </br></br>  Kan bağışı ve kan ile alakalı bilinmesi gerekenleri en ince detayına kadar öğrenmek istiyorsan seni de etkinliğimize bekliyoruz.
                              </br> <span>📅 11 Mayıs 2021</span></br>
                              <span>⏰ 14:00⠀</span></br>
                              <span>💻 Zoom</span></br>
                              <a href="https://docs.google.com/forms/d/e/1FAIpQLSdxu3esWFHyy00ZBOW6l2XoB5FpmgCwx6sIwBBQ0Ivcco9Qmg/viewform" style="color: #00b3ee; font-weight: bold;" target="_blank"><span>📜 Katılım Formu</span></a>
                          </p>
                      </div>

                    </div>

                </div>

            </div>
        </div>


<?php require 'static/footer.php'; ?>