<?php
define("view","security");
require 'header.php';
?>
<header id="gtco-header" class="gtco-cover gtco-cover-xs gtco-inner" role="banner">
			<div class="gtco-container">
				<div class="row">
					<div class="col-md-12 col-md-offset-0 text-left">
						<div class="display-t">
							<div class="display-tc">
								<div class="row">
									<div class="col-md-8">
										<h1 class="no-margin">Hakkımızda</h1>
										<p>PAY Gençlik, demokratik, laik, bağımsız, şeffaf ve politikalar üstü “PAY’ına düşeni YAP” felsefesiyle oluşturulmuş, odak noktası gençler olan bir sivil toplum girişimidir. </p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>
		<!-- END #gtco-header -->
    <div class="gtco-services gtco-section">
        <div class="gtco-container">
            <div class="row">
                <div class="hakkimda col-lg-12 col-md-12   gtco-heading gtco-staff" id="hakkimizda">
                    <div class="img col-lg-4 col-md-5 hedocenter col-sm-5 ">
                        <img src="images/society.jpg" alt="" width="300" height="auto" style="border-radius: 10px; border: rgba(120,114,114,0.71) solid 2px;">
                    </div>
                    <div class="col-lg-8 col-md-7 col-sm-7 about-text">
                        <p style="font-size: 15px;">PAY Gençlik, paylaşmayı yaşamın merkezine alan, paylaşmanın ve ortak hareket etmenin gücüne inanan, Farabi’nin Hak, Liyakat, Pay teorisinden aldığı ilhamla gençliğin dolayısıyla toplumun kalkınmasını hedefleyen, gençlerle iyiliği, güzelliği ve bilgiyi paylaşma da payına düşeni yapmaya çalışan profesyonellerin ortak bir paydada toplanarak kurduğu bir gençlik derneğidir.
                            Pay Gençlik’in başlıca amacı; toplum farkındalığı yüksek, sorumluluk bilinci gelişmiş, yaşam ve iş etiği olan, özgüvenli, profesyonel alanının yanı sıra farklı alanlarda da donanımlı ve vizyonu geniş aktif gençlerin yetişmesine katkıda bulunarak, gençlerin gençler eliyle kalkınmasını sağlamaktır.
                            Bu amaçları gerçekleştirebilmek için yerel, ulusal ve uluslararası platformlarda gençlik çalışmaları, sosyal sorumluluk ve farkındalık faaliyetleri, interaktif eğitim çalışmaları, kültürel etkinlikler ve Avrupa Birliği proje uygulamaları konularında payımıza düşeni yapma motivasyonuyla Pay Gençlik olarak çalışmalarımızı gerçekleştiriyoruz.

                            </br></br><b>Sende PAY’ına düşeni YAPmak için yola çıktıysan ve paydaş arıyorsan, biz burdayız.</b>


                            </br></br><b>PAY Gençlik, demokratik, laik, bağımsız, şeffaf ve politikalar üstü “PAY’ına düşeni YAP” felsefesiyle oluşturulmuş, odak noktası gençler olan bir sivil toplum girişimidir. </b></p>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php require 'biz-kimiz-slider.php';?>



<?php
require 'footer.php';
?>