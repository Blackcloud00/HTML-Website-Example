<?php
define("view","security");
require 'header.php';
?>
<div class="gtco-section" style="padding-top: 3em;padding-bottom: 3em;">
			<div class="gtco-container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 gtco-heading text-center">
						<h2>İletişim</h2>
						<p>PAY Gençlik Derneği ile ilgili kafanızda soru işareti varsa bize buradan ulaşabilirsiniz...</p>
					</div>
				</div>
				<div class="row">

					<div class="col-md-6">
                        <?php if(isset($_GET['success'])): ?>
                            <div class="text-success" >BAŞARIYLA MAİL GÖNDERİLDİ...</div>
                        <?php endif ?>
                        <?php if(isset($_GET['failed'])): ?>
                            <div class="text-failed" >MAİL GÖNDERİLEMEDİ!!!!</div>
                        <?php endif ?>
						<form method="POST"  action="iletisim_post.php">
							<div class="form-group" >
								<label for="name">İsim Soyisim</label>
								<input type="text" name="adi_soyadi" class="form-control"  id="name" required="">
							</div>
							<div class="form-group">
								<label for="name">E-mail</label>
								<input type="text" name="email" class="form-control" id="email"  required="">
							</div>
                            <div class="form-group">
                                <label for="name">Telefon</label>
                                <input type="text" name="telefon" class="form-control" id="phone"  required="">
                            </div>
							<div class="form-group">
								<label for="message"></label>
								<textarea name="mesaj" id="message" cols="30" rows="10" class="form-control"></textarea>
							</div>
							<div class="form-group">
								<input type="submit"  class="btn btn btn-special" value="Mesaj Gönder">
							</div>
                        </form>
					</div>
					<div class="col-md-5 col-md-push-1">
						<div class="gtco-contact-info">
							<h3>Adreslerimiz</h3>
							<ul >
								<li class="address">Ankara/Türkiye</li>
								<li class="email"><a href="mailto:iletisim@paygenclikdernegi.org">iletisim@paygenclikdernegi.org</a></li>
								<li class="email"><a href="mailto:partnership@paygenclikdernegi.org">partnership@paygenclikdernegi.org</a></li>
								<li class="email"><a href="mailto:project@paygenclikdernegi.org">project@paygenclikdernegi.org</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
<?php
require 'footer.php';
?>