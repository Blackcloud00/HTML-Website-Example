<?php defined('view') or die('<script>location.href="404"</script><META HTTP-EQUIV=REFRESH CONTENT="0; 404">');
?>
<div class="gtco-services gtco-section">
    <div class="gtco-container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 gtco-heading text-center">
                <h2>Hakkımızda</h2>
            </div>
        </div>
        <div class="row">
            <div class="hakkimda col-lg-12 col-md-12   gtco-heading gtco-staff" id="hakkimizda">
                <div class="img col-lg-4 col-md-5 hedocenter col-sm-5 ">
                    <img src="images/society.jpg" alt="" width="300" height="auto" style="border-radius: 10px; border: rgba(120,114,114,0.71) solid 2px;">
                </div>
                <div class="col-lg-8 col-md-7 col-sm-7 about-text">
                    <p style="font-size: 20px;"><b>Sende PAY’ına düşeni YAPmak için yola çıktıysan ve paydaş arıyorsan, biz burdayız.</b>


                        </br></br><b>PAY Gençlik, demokratik, laik, bağımsız, şeffaf ve politikalar üstü “PAY’ına düşeni YAP” felsefesiyle oluşturulmuş, odak noktası gençler olan bir sivil toplum girişimidir. </b><a href="hakkimizda.php#hakkimizda" style="text-decoration: underline;">  Devamı...</a></p>
                </div>
            </div>
        </div>
    </div>
</div>