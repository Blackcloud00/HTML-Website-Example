<?php
/*Veri Tabanı bağlantısı için gerekli dosya...*/

header('Content-Type: text/html; Charset=UTF-8');
date_default_timezone_set('Europe/Istanbul');

define('MYSQL_HOST', 'localhost');
define('MYSQL_DB', 'paygenclik');
define('MYSQL_USER', 'root');
define('MYSQL_PASS', '');

include 'db.php';