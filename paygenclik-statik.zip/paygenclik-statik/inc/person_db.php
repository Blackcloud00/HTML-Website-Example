<?php
defined('view') or die('<script>location.href="404"</script><META HTTP-EQUIV=REFRESH CONTENT="0; 404">');
$person = [
    [
        "name" => "Mustafa Çalışkan",
        "des-sum" => "Uzun yıllardır gençlik çalışmaları alanında ulusal ve uluslararası boyutta gönüllü olarak sayısız faaliyet yürüterek; birçok sivil toplum girişiminde aktif rol aldım.",
        "des" => "Uzun yıllardır gençlik çalışmaları alanında ulusal ve uluslararası boyutta gönüllü olarak sayısız faaliyet yürüterek; birçok sivil toplum girişiminde aktif rol aldım. Avrupa Birliği’nin gençlik alanındaki programları ile ilgili çalışmalarıma lise döneminde başlayarak üniversite hayatımda yoğunluk verdim. Bu programlar kapsamında 12 farklı ülkede kısa ve uzun sürelerde sosyal çalışmalar gerçekleştirdim. Programlar sayesinde iki farklı Avrupa ülkesinde uzun süreli olarak yaşama imkanı yakaladım ve çalışmalarımı geliştirdim. Projelerde edindiğim tecrübeleri tüm gençlere aktarabilmek ve gençlerin katılımını desteklemek adına sosyal medya kanallarında da (<a href='https://www.instagram.com/projegezgini/' target='_blank' style='color: #00b3ee;'>@projegezgini</a>) aktif olarak faaliyet gösteriyorum.
</br></br>
Bu sosyal Mustafa’nın dışında tabii ki bir de akademik ve mesleki boyutu olan bir Mustafa var. O Mustafa ise Sakarya Üniversitesi Siyaset Bilimi ve Kamu Yönetimi Lisans programı son sınıf öğrencisi aynı zamanda Ankara Valiliği AB ve Dış İlişkiler Bürosu’nda görev alıyor ve Ankara’da 3 farklı derneğin European Solidarity Corps (ESC) programı kapsamındaki projeleriyle Türkiye’ye gelen Avrupalı gönüllü gençlere mentorluk yapıyor.
 </br></br>
Her iki Mustafa’da şu anda sivil toplum faaliyetlerine PAY Gençlik’in Kurucu Başkanı olarak devam etmekten büyük mutluluk ve heyecan duyuyor. Yollarımızın kesişmesi ve birçok güzel düşünceyi beraber PAYlaşmak üzere!",

        "role" => "Yönetim Kurulu Başkanı",
        "img-slide" => "mustafa_caliskan_slide.jpg",
        "img" => "mustafa_caliskan.jpg",
        "id" => "mustafa.caliskan",
        "mail" => "mustafa.caliskan@paygenclikdernegi.org",
        "social" => [

            [
                "sname" => "instagram",
                "link" => "https://www.instagram.com/projegezgini/",
            ],
            [
                "sname" => "linkedin",
                "link" => "https://www.linkedin.com/in/mustafacaliskan-00/",
            ],
        ],

    ],
    [
        "name" => "Dilek Köselioğlu",
        "des-sum" => "1993 yılında Ankara’dan dünyaya merhaba dedim. İlköğretim ve lise hayatım Ankara’da geçti. 2015 yılında Bursa Uludağ Üniversitesi Zihin Engelliler Öğretmenliği programından mezun oldum.",
        "des" => "1993 yılında Ankara’dan dünyaya merhaba dedim. İlköğretim ve lise hayatım Ankara’da geçti. 2015’te Uludağ Üniversitesi Zihin Engelliler Öğretmenliği programından mezun oldum. Lisansımın son yılında Farabi Değişim Programıyla Gazi Üniversitesine geçiş yaptım. Bu sayede alanıma dair farklı ekoller tanımanın yanı sıra başka bir üniversitenin kültürünü de yaşama fırsatı buldum. Ayrıca üniversite döneminde öğrenci topluluklarıyla birlikte dezavantajlı ve lösemili çocuklarla sosyal sorumluluk etkinliklerine katılım gösterdim. 
</br></br>
Mezun olduktan sonra Ankara’da kısa süreli olarak özel eğitim ve rehabilitasyon merkezlerinde özel eğitim öğretmeni olarak görev yaptım. Ardından Şubat 2016’da ise Ankara’da bir devlet okuluna özel eğitim öğretmeni olarak atandım. Mesleğimin ilk yılında Avrupa Birliği kapsamında bir proje faaliyetine katıldım. Proje sürecinde Budapeşte’de, Macaristan özel eğitim sistemi hakkında bilgilenerek, okul ve enstitülerinde vakit geçirerek, mesleki bilgilerimi geliştirme, vizyonuma yeni perspektifler katma imkanı elde ettim. 

</br></br>
Mesleğimle eş zamanlı olarak ise Mart 2020’de Gazi Üniversitesi Zihin Engellilerin Eğitimi Anabilim Dalı Tezli- Yüksek Lisans Programını tamamladım. Bir taraftan akademik gelişimim ve ilerlemem için çalışmalara devam ederken aktif olarak da MEB’te öğretmenliğe devam ediyorum.  
</br></br>
Bunlar beni mesleki ve akademik yönden tanıtan bilgilerdi. Sizlere neden PAY Gençlik’te olmak istediğimden ve neden burada olduğumdan kısaca bahsetmek istiyorum. 
Yaşamı daha anlamlı ve değerli kılanın diğer canlılarla “ <b>pay</b>laşabilmek” olduğunu düşünüyorum. Bunun için faydalı etkinliklerin, projelerin üretilmesi ve uygulanmasında vaktimi, enerjimi, bilgimi  <b>pay</b>laşmayı istedim. En azından bunu gerçekten denemeyi istedim. İlber Hoca’nın da dediği gibi hiçbir şey olmasa bile, ki olmak zorunda da değil. Bunlar yeni bir yaşamı görmemi sağlayacak. 
Gençliğe ve yaşama güzel dokunuşlarda bulunabilmek dileğimle PAY Gençlik’in  kuruluşunda ve bünyesinde <b>pay</b>ım olmasından mutluluk duyuyorum.",
        "role" => "Yönetim Kurulu Başkan Yardımcısı",
        "img-slide" => "dilek_koselioglu_slide.jpg",
        "img" => "dilek_koselioglu.jpg",
        "id" => "dilek.koselioglu",
        "mail" => "dilek.koselioglu@paygenclikdernegi.org",
        "social" => [
            [
                "sname" => "instagram",
                "link" => "https://www.instagram.com/dilek.koselioglu/",
            ],
            [
                "sname" => "linkedin",
                "link" => "https://www.linkedin.com/in/dilek-k%C3%B6selio%C4%9Flu-52677a1a6/",
            ],
        ],

    ],
    [
        "name" => "Merve Simsek",
        "des-sum" => "TOBB Ekonomi ve Teknoloji Üniversitesi Görsel İletişim Tasarımı Bölümü mezunu olan Merve Şimşek, üniversite döneminin ilk yıllarından beri çeşitli öğrenci topluluklarında aktif görevlerde rol almıştır.",
        "des" => "TOBB Ekonomi ve Teknoloji Üniversitesi Görsel İletişim Tasarımı Bölümü mezunu olan Merve Şimşek, üniversite döneminin ilk yıllarından beri çeşitli öğrenci topluluklarında aktif görevlerde rol almıştır. Bir dönem Genç Kızılay üniversite topluluğu başkanlığı yürütmüş; Fotoğrafçılık ve Geleneksel Türk Okçuluğu kulüplerinin yönetim kurulunda yer almıştır. Genç Kızılay Ankara Kurumsal İletişim Birimi'nde görev almış ve çeşitli gönüllü faaliyetlerine katılmıştır. Aktif olarak okçuluk ve binicilik alanlarıyla ilgilenmektedir. Ulusal ve uluslararası çeşitli yayınevi ve reklam ajanslarında tasarımcı olarak çalışmış, mesleki alanda kendini geliştirmeye devam etmektedir.",
        "role" => "Yönetim Kurulu Üyesi",
        "img-slide" => "merve_simsek_slide.jpg",
        "img" => "merve_simsek.jpg",
        "id" => "merve.simsek",
        "mail" => "merve.simsek@paygenclikdernegi.org",
        "social" => [
            [
                "sname" => "instagram",
                "link" => "https://www.instagram.com/mervee.simsek/",
            ],
        ],

    ],
    [
        "name" => "Sare Büşra Göncü",
        "des-sum" => "Sare Büşra, 1997’de Ankara’da dünyaya gelmiştir. Çocukluk ve gençlik çağlarını Ankara’da geçiren Sare daha sonrasında Selçuk Üniversitesi’nde Fransız Dili ve Edebiyatı bölümünü kazandı. ",
        "des" => "Sare Büşra, 1997’de Ankara’da dünyaya gelmiştir. Çocukluk ve gençlik çağlarını Ankara’da geçiren Sare daha sonrasında Selçuk Üniversitesi’nde Fransız Dili ve Edebiyatı bölümünü kazandı ve kendini Konya’da buldu. Fakat Edebiyat bölümünün kendisine göre olmadığını düşünen Sare, Fransızca hazırlık sınıfını tamamladıktan sonra Kırıkkale Üniversitesi Fransızca Mütercim ve Tercümanlık bölümünde eğitimine devam etme kararı aldı. Şu an bu bölümdeki lisans eğitimine devam etmektedir. Üniversite hayatı boyunca bir çok kurum ve kuruluşta yer alan Sare çok aktif bir üniversite hayatı geçirmiştir ve geçirmektedir.</br></br>
Sanat ve spor alanlarına ilgi duyan Sare, atları çok seviyor  ve binicilik eğitimi alıyordur. Ayrıca ,3 senedir lisanslı olarak okçuluk sporuyla uğraşıyor.Sanat alanında bir çok kurumdan eğitim alan Sare , Ebru sanatı ve karakalem eğitimi alırken ilgi alanlarına yönelik bir gençlik değişimi  projesi yazmak ister ve buna yönelik adımlar atmaya başlar. Bu adımlar Sare’yi birçok kuruluşta gönüllü olarak çalışmaya sevk eder ve Sare’nin gençlik alanında birçok deneyim kazanmasına sebep olur.  Sare, şu anda Tunus’ta gençlik çalışmaları ile ilgili bir  kısa dönem Avrupa Birliği European Solidarity Corsp projesinde görev almaktadır.Son olarak bir e dergide yazılar yazan Sare, kendince okurlarına seslenmeye çalışmaktadır.",
        "role" => "Yönetim Kurulu Üyesi",
        "img-slide" => "sare_busra_slide.jpg",
        "img" => "sare_busra.jpg",
        "id" => "sare.busra",
        "mail" => "sare.busra.goncu@paygenclikdernegi.org",
        "social" => [
            [
                "sname" => "facebook",
                "link" => "https://www.facebook.com/SareeBusraa/",
            ],
            [
                "sname" => "instagram",
                "link" => "https://www.instagram.com/sare.busrra/?igshid=avi7453t7gln",
            ],
        ],

    ],
    [
        "name" => "Duygu Naz Dedeoğlu",
        "des-sum" => "Duygu Naz DEDEOĞLU, 1999’da Ankara’da doğdu. Lise eğitiminin ilk 3 yılını Hürriyet Anadolu Lisesi’nde, geri kalan eğitimini ise Üçler Temel Lisesinde tamamlamıştır.",
        "des" => "Duygu Naz DEDEOĞLU, 1999’da Ankara’da doğdu. Lise eğitiminin ilk 3 yılını Hürriyet Anadolu Lisesi’nde, geri kalan eğitimini ise Üçler Temel Lisesinde tamamlamıştır. Lise hayatında birçok gönüllülük faaliyetine katılmış ve TÜBİTAK 4006 proje yarışmasında okulunu temsil etmiştir. Çankaya Üniversitesi Psikoloji bölümü 3. sınıf öğrencisidir. Aynı zamanda İstanbul Üniversitesi Açık ve Uzaktan Eğitim Fakültesi Çocuk Gelişimi bölümü 2. sınıf öğrencisidir. Ankara’da Ortadoğu Engelsiz Eğitim Derneği’nde görme engelli öğrenciler için gönüllü okutmanlık ve öğrenci danışmanlığı yapmaktadır. Ankara Esat Leo Kulübü üyesidir. TOG Vakfı, LÖSEV ve Vakıf Üniversiteleri Komitesi’nde gönüllü faaliyetlerini sürdürmektedir. Bi’şey Psikoloji AR-GE ekibi çalışanıdır ve bir süre Türk Psikologlar Derneği (TPD) Öğrenci Koordinasyon Grubu (ÖKG) Dezavantajlı Gruplarla Çalışma Komisyonu'nda komisyon sorumlusu olarak görev yapmıştır. Türk Psikoloji Öğrencileri Çalışma Grubu'nda (TPÖÇG) Lise Öğrencilerine Yönelik Çalışma Ekibi (LÖYÇE) 2019-2020 elçiliği, 2020-2021 yılında Proje Geliştirme Ekibi çalışanlığı yapmış ve ekibiyle birlikte \"Tohumdan Fidana\" isimli bir proje yazmıştır. Halihazırda yine Türk Psikoloji Öğrencileri Çalışma Grubu'nda Dış İşler Koordinatörü ve Türkiye'nin Avrupa Psikoloji Öğrencileri Birlikleri Federasyonu'nda (EFPSA) üye temsilciliğini yapmaktadır. Yine Avrupa Psikoloji Öğrencileri Birlikleri Federasyonu'nun birçok ülkeyle beraber Türkiye'de de yürüttüğü Mind the Mind projesi gönüllüsüdür.",
        "role" => "Yönetim Kurulu Üyesi",
        "img-slide" => "duygu_naz_dedeoglu_slide.jpg",
        "img" => "duygu_naz_dedeoglu.jpg",
        "id" => "duygu.naz",
        "mail" => "duygu.naz.dedeoglu@paygenclikdernegi.org",
        "social" => [
            [
                "sname" => "instagram",
                "link" => "https://www.instagram.com/duygunazdedeoglu",
            ],
            [
                "sname" => "linkedin",
                "link" => "https://www.linkedin.com/in/duygunazdedeoglu",
            ],
        ],

    ],
    [
        "name" => "Hilal Keçeli",
        "des-sum" => "1993 yılının eylül ayında Ankara'da doğdu. Çocukluğu eve girmemek için verdiği mücadele ile geçti. Karakterinin inatçılık kısmı burada filizlendi.    ",
        "des" => "1993 yılının eylül ayında Ankara'da doğdu. Çocukluğu eve girmemek için verdiği mücadele ile geçti. Karakterinin inatçılık kısmı burada filizlendi. 
İlk,orta ve lise öğrenimini Ankara'da tamamladı. Üniversiteyi Kırıkkale'de, Çocuk Gelişimi bölümünde okudu. Üniversitesinin ev sahipliğini yaptığı 'Ulusal Çocuk Gelişimi Öğrenci Kongresi' nde bilim kurulu üyeliği yaptı. Bunun yanında bölüm temsilciliği yaptı ve çeşitli topluluklarda görev aldı. 
Mezuniyetten sonra Ankara'ya döndü. Eğitim ve danışmanlık merkezinde, bir kolejin anaokulu biriminde ve bir özel eğitim ve rehabilitasyon merkezinde, alanında tecrübeler edindi. Şu an da son çalıştığı kurumda özel çocuklarla çalışmaya devam etmektedir. 
Spiritüel konulara ilgi duyan, araştırmacı ruhlu, kitapları, gezmeyi, keşfetmeyi çok seven meraklı bir feministtir. ",
        "role" => "Yönetim Kurulu Üyesi",
        "img-slide" => "hilal_keceli_slide.jpg",
        "img" => "hilal_keceli.jpg",
        "id" => "hilal.keceli",
        "mail" => "hilal.keceli@paygenclikdernegi.org",
        "social" => [
            [
                "sname" => "twitter",
                "link" => "https://twitter.com/KeceliHilal",
            ],
            [
                "sname" => "instagram",
                "link" => "https://www.instagram.com/hilalkeceli/",
            ],
            [
                "sname" => "linkedin",
                "link" => "https://www.linkedin.com/in/hilal-keçeli-51b513105",
            ],
        ],

    ],
    [
        "name" => "Olgun Karabulut",
        "des-sum" => "2001 Yılında İzmir de doğdum. İlk bilgisayarla tanışmam 5 yaşında oldu, o zamandan beri  teknoloji ile büyük bir merak ile ilgileniyorum. ",
        "des" => "2001 Yılında İzmir de doğdum. İlk bilgisayarla tanışmam 5 yaşında oldu, o zamandan beri  teknoloji ile büyük bir merak ile ilgileniyorum. Lise de yazılım kelimesini ve ne olduğunu bir arkadaşımdan duymam üzerine dönem ortasında  radikal bir karar alıp bir anda pazarlama bölümünden bilişim bölümüne geçiş yaptım. Hiçbir bilgim olmadığı alanda ilk programlama sınavının derslerine girmemiştim, sınava bir gün kalmışken, normalde ders çalışmayan ben o gün 10 saat boyunca algoritma mantığını kavramaya çalıştım ve sınıfta 70 puan ile en yüksek notu alan 2. kişi oldum. Bu ufak başarıdan sonra yazılım alanına olan motivasyonum arttı ve doğru bilişim öğretmenlerinin yönlendirmeleri sayesinde birçok bilim, robot yarışmalarına katıldım ve çok güzel tecrübeler edindim, Erasmus+ kapsamında yurtdışında staj yapma imkanım oldu. 12. sınıfta da profesyonel bir web ajansında staj yapma imkanım oldu bana çok şey kattı. Şuanda hem üniversiteye hazırlanıyorum hem de web geliştirmede kendimi geliştiriyorum. Uzun lafın kısası önce kendimi sonra çevremi geliştiriyorum. :)",
        "role" => "Yönetim Kurulu Üyesi",
        "img-slide" => "olgun_karabulut_slide.jpg",
        "img" => "olgun_karabulut.jpg",
        "id" => "olgun.karabulut",
        "mail" => "olgun.karabulut@paygenclikdernegi.org",
        "social" => [
            [
                "sname" => "instagram",
                "link" => "https://www.instagram.com/olgun.karabulut/",
            ],
            [
                "sname" => "linkedin",
                "link" => "https://www.linkedin.com/in/olgun-karabulut-46a11a182/",
            ],
        ],

    ],
];