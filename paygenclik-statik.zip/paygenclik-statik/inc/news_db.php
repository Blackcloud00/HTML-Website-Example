<?php
defined('view') or die('<script>location.href="404"</script><META HTTP-EQUIV=REFRESH CONTENT="0; 404">');
$news = [
    [
        "title" => "Dolunay Yogasına Var Mısın?",
        "date" => "26.05.2021",
        "id" => "1",
        "img" => "dolunay-yoga.jpg",
        "files_name" => "dolunay-yoga",
        "des_sum_slide" => "Dolunaylar içimizde birikenleri temizleme zamanıdır.",
        "des_sum" => "Dolunaylar içimizde birikenleri temizleme zamanıdır. Ve dolunayla birlikte ay tutulmasıda aynı zamana denk geldi. Ay tutulması dönemlerinde gergin ve sinirli olabiliriz.</br> Bu kadar üst üste doğa olayları bize ruhumuzu ve bedenimizi dinlendirmemizi söylüyorsa haydi durmayalım ne dersin?",
        "des" => "#",
    ],
     [
        "title" => "ÜCRETSİZ yurt dışı fırsatları",
        "date" => "21.05.2021",
        "id" => "1",
        "img" => "erasmus-nedir.jpg",
        "files_name" => "erasmus-nedir",
        "des_sum_slide" => " Evet evet doğru okudunuz, ‘ÜCRETSİZ’ yurt dışı fırsatları. ",
        "des_sum" => "Evet evet doğru okudunuz, ‘ÜCRETSİZ’ yurt dışı fırsatları.</br></br>Avrupa Birliği’nin nasıl projeleri var? </br>Bu projelere kimler ve nasıl katılabilir?</br>Erasmus+ nedir?",
        "des" => "#",
    ],
    [
        "title" => "19 Mayıs 2021",
        "date" => "19.05.2021",
        "id" => "1",
        "img" => "19-mayis-2021.jpg",
        "files_name" => "19-mayis-2021",
        "des_sum_slide" => "19 Mayıs güven, sevinç, hareket günüdür. Atatürk'ü Anma Gençlik ve Spor Bayramımız kutlu olsun.",
        "des_sum" => "19 Mayıs güven, sevinç, hareket günüdür. Atatürk'ü Anma Gençlik ve Spor Bayramımız kutlu olsun.",
        "des" => "#",
    ],
    [
        "title" => "Kapsayıcı Eğitim",
        "date" => "16.05.2021",
        "id" => "1",
        "img" => "ozel-ogretim.jpg",
        "files_name" => "ozel-ogretim",
        "des_sum_slide" => "Kapsayıcı eğitim anlayışını daha önce duymuş muydunuz?",
        "des_sum" => "Kapsayıcı eğitim anlayışını daha önce duymuş muydunuz? </br></br>Yalnızca eğitimcileri, öğrencileri değil toplumdaki her bireyi ilgilendiren oldukça önemli bir yaklaşım.",
        "des" => "#",
    ],

 [
    "title" => "Kan Bağışı ile İlgili Her Şey",
    "date" => "11.05.2021",
    "id" => "1",
    "img" => "kizilay-kan-haftasi.jpg",
    "files_name" => "kizilay-kan-haftasi",
    "des_sum_slide" => "Ülkemizde her yıl 6-12 Mayıs tarihleri Türk Kızılayı tarafından “Kızılay Kan Haftası” olarak kutlanıyor.",
    "des_sum" => "Ülkemizde her yıl 6-12 Mayıs tarihleri Türk Kızılayı tarafından “Kızılay Kan Haftası” olarak kutlanıyor. </br></br> Kan, yapay olarak üretilmesi mümkün olmayan bir dokudur ve tek kaynağı diğer sağlıklı insanlardır.",
    "des" => "#",
  ],
    [
        "title" => "Engelliler Haftası",
        "date" => "10.05.2021",
        "id" => "2",
        "img" => "engel-olmazsak.jpg",
        "files_name" => "engel-olmazsak",
        "des_sum_slide" => "İçinde bulunduğumuz hafta Birleşmiş Milletlere üye ülkelerde “Engelliler Haftası” olarak anılıyor.",
        "des_sum" => "İçinde bulunduğumuz hafta Birleşmiş Milletlere üye ülkelerde “Engelliler Haftası” olarak anılıyor. </br></br> Gelin bu konuda PAYımıza düşenleri sadece bir haftaya, bir güne veya bir sosyal medya paylaşımına sığdırmayalım. ",
        "des" => "#",
    ],
 [
        "title" => "Bugün Avrupa Günü",
        "date" => "09.05.2021",
        "id" => "3",
        "img" => "avrupa-gunu.jpg",
        "files_name" => "avrupa-gunu",
      "des_sum_slide" => "🇪🇺 Avrupa Birliği’nin kuruluş adımlarının atıldığı gün olarak anılan ve Avrupa’da barışçıl hareketlerin, dayanışmanın,",
      "des_sum" => "🇪🇺 Avrupa Birliği’nin kuruluş adımlarının atıldığı gün olarak anılan ve Avrupa’da barışçıl hareketlerin, dayanışmanın, birliğin sembolü olan 9 Mayıs “Avrupa Günü” kutlu olsun! 🇪🇺",
      "des" => "#",
    ],
   [
        "title" => "Ev Bitkilerinin Bakımı",
        "date" => "08.05.2021",
        "id" => "4",
        "img" => "ev-bitklileri.jpg",
        "files_name" => "ev-bitkileri",
        "des_sum_slide" => "Yazın kendini iyice hissettirmesiyle, yeşilliğin içinde kaybolmak, çimenlere uzanıp gökyüzünü izlemek,",
        "des_sum" => "Yazın kendini iyice hissettirmesiyle, yeşilliğin içinde kaybolmak, çimenlere uzanıp gökyüzünü izlemek, tüm çiçekleri koklamak istediğimiz bu süreçlerde evde ilkbahar esintileri yaşamamız mümkün. Nasıl mı? Elbette evde bitki yetiştirmeye başlayarak! </br></br> Belki evinizde bitkiler var ama onları daha sağlıklı büyütmeyi sağlayacak bilgiler arıyorsunuz; belki de özellikle pandemi sürecinde bitki bakımıyla ilgilenmeye başladınız ama onlara nasıl bakacağınız konusunda daha fazla bilgi edinmek istiyorsunuz.",
        "des" => "#",
    ],
   [
        "title" => "Gelin Tanış Olalım",
        "date" => "03.05.2021",
        "id" => "5",
        "img" => "tanis.jpg",
        "files_name" => "tanis",
        "des_sum_slide" => "3 Mayıs Pazartesi günü 21:00’de PAY Gençlik Derneği Tanışma Toplantısında buluşuyoruz!",
        "des_sum" => "3 Mayıs Pazartesi günü 21:00’de PAY Gençlik Derneği Tanışma Toplantısında buluşuyoruz! </br></br> COVID-19 sürecinde sizlerle ekranlardan da olsa yüz yüze tanışmak, derneğimizle ilgili sorularınızı yanıtlamak ve önerilerinizi dinlemek istiyoruz.⠀",
        "des" => "#",
    ],
   [
        "title" => "Biz Kimiz?",
        "date" => "23.04.2021",
        "id" => "6",
        "img" => "biz-kimiz.jpg",
        "files_name" => "biz-kimiz",
        "des_sum_slide" => "PAY Gençlik, paylaşmayı yaşamın merkezine alan, paylaşmanın ve ortak hareket etmenin gücüne inanan,",
        "des_sum" => "PAY Gençlik, paylaşmayı yaşamın merkezine alan, paylaşmanın ve ortak hareket etmenin gücüne inanan, Farabi'nin \"Hak, Liyakat, Pay\" teorisinden aldığı ilhamla gençliğin dolayısıyla toplumun kalkınmasını hedefleyen, gençlerle iyiliği, güzelliği ve bilgiyi paylaşma da payına düşeni yapmaya çalışan profesyonellerin ortak bir paydada toplanarak kurduğu bir gençlik derneğidir.",
        "des" => "#",
    ],
    [
        "title" => "Pay Gençlik Derneği Kuruldu",
        "date" => "20.04.2021",
        "id" => "7",
        "img" => "pay-genclik-dernegi-kuruldu.jpg",
        "files_name" => "pay-genclik-dernegi-kuruldu",
        "des_sum_slide" => "Paylaşmayı seven, doğaya ve hayata karşı duyarlı olan tüm gençlerin birbirleri ile her konuda paylaşımlar",
        "des_sum" => "Paylaşmayı seven, doğaya ve hayata karşı duyarlı olan tüm gençlerin birbirleri ile her konuda paylaşımlar yaparak karşılıklı bir şeyler katması için el ele verip Pay Gençlik Derneğini kurduk.",
        "des" => "#",
    ],

];







