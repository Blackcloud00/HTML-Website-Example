<div class="container-fluid slider-derman">
    <div class="swiper-container">
        <div class="swiper-wrapper">
            <div class="swiper-slide" style="background-image:url(assets/img/m1.jpg);"><h2 class="slide-name">Eames -</br> Side Chair.</h2> <p class="slide-p">Semper vulputate aliquam curae</br> condimentum quisque gravida fusce</br>  convallis arcu cum at.</p> <h3 class="slide-fiat">Only $99.00</h3></div>
            <div class="swiper-slide" style="background-image:url(assets/img/m2.jpg)"><h2 class="slide-name">Simple -</br> Rock Chair.</h2> <p class="slide-p">Semper vulputate aliquam curae</br> condimentum quisque gravida fusce</br>  convallis arcu cum at.</p> <h3 class="slide-fiat">$199.00</h3></div>
            <div class="swiper-slide" style="background-image:url(assets/img/m3.jpg);"><b class="capelini">CAPPELLINI</b><H1 class="slide-name-2">WOODEN </br>LOUNGE CHAIRS</H1> <p class="slide-p-2">Semper vulputate aliquam curae</br> condimentum quisque gravida fusce</br>  convallis arcu cum at.</p><h3 class="slide-fiat-2">$999.00</h3></div>
        </div>

        <!-- Add Pagination -->
        <div class="swiper-pagination swiper-pagination-white"></div>
        <!-- Add Arrows -->
        <div class="swiper-button-next swiper-button-white"></div>
        <div class="swiper-button-prev swiper-button-white"></div>
    </div>
</div>


