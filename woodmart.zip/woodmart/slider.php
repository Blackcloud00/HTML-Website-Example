
<div class="container-fluid slider-derman">
    <div class="swiper-container">
        <div class="swiper-wrapper">
            <div class="swiper-slide" style="background-image:url(assets/img/m1.jpg);"><h2 style=" font-size: 55px;position: relative; left: 31%;">Eames -</br> Side Chair.</h2></div>
            <div class="swiper-slide" style="background-image:url(assets/img/m2.jpg)"></div>
            <div class="swiper-slide" style="background-image:url(assets/img/m3.jpg)"></div>
        </div>

        <!-- Add Pagination -->
        <div class="swiper-pagination swiper-pagination-white"></div>
        <!-- Add Arrows -->
        <div class="swiper-button-next swiper-button-white"></div>
        <div class="swiper-button-prev swiper-button-white"></div>
    </div>
</div>


