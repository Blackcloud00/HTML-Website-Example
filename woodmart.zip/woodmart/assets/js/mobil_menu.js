window.addEventListener("load", () => {
    document.body.classList.remove("preload");
});

document.addEventListener("DOMContentLoaded", () => {
    const nav = document.querySelector(".nav");

    document.querySelector("#btnNav").addEventListener("click", () => {
        nav.classList.add("nav--open");
    });

    document.querySelector(".nav__overlay").addEventListener("click", () => {
        nav.classList.remove("nav--open");
    });
});


var deleteitem=document.getElementById("kolda");
deleteitem.onclick=function () {
   document.querySelector('#asd2').classList.add('d-none');
    document.querySelector('#asd1').classList.remove('d-none');
    document.querySelector('#kolda').classList.add('active');
    document.querySelector('#solda').classList.remove('active');
    document.querySelector('#solda').classList.remove('bttm-50');
}
var deleteite2=document.getElementById("solda");
deleteite2.onclick=function () {
    document.querySelector('#solda').classList.add('bttm-50');
    document.querySelector('#asd1').classList.add('d-none');
    document.querySelector('#solda').classList.add('active');
    document.querySelector('#kolda').classList.remove('active');
    document.querySelector('#asd2').classList.remove('d-none');
}

