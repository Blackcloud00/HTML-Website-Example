<header class="header buton-toggle">
    <button class="header__button" id="btnNav" type="button">
        <i style="font-size: 18px;top: 5px;position: relative;" class="icon-list"><span
                    style="font-size: 16px;padding-left: 8px;font-style: initial;" class="menu-text">MENU</span></i>
    </button>
</header>
<nav class="nav mobil-menu" >
    <div class="nav__links" style=" z-index: 10;">
        <a href="#" class="nav__link">
            <form>
                <input type="text" placeholder="Search for products">
                <button type="submit"><i class="icon-search"></i></button>
            </form>
        </a>
        <ul class="navbar-nav" style="position: relative;bottom: 15px;">
            <li class="ds-menu nav-item" style="z-index: 10;">
                <a  id="kolda" class="dropdown-header nav__head asd-1head" style="z-index: 10;">
                    <span class="nav__htext">MENU</span>
                </a>
                <div id="asd1">
                    <a href="#" class=" dropdown-item  nav__link asd-1">
                        HOME <i class="icon-right-arrow"></i>
                    </a>
                    <a class="dropdown-item  nav__link asd-1" href="#">
                        SHOP
                    </a>
                    <a class="dropdown-item nav__link asd-1" href="#">
                        BLOG
                    </a>
                    <a class="dropdown-item nav__link asd-1" href="#">
                        PORTFOLIO
                    </a>
                    <a class="dropdown-item nav__link asd-1" href="#">
                        PAGES <i class="icon-right-arrow"></i>
                    </a>
                    <a class="dropdown-item nav__link asd-1" href="#">
                        WISHLIST
                    </a>
                    <a class="dropdown-item nav__link asd-1" href="#">
                        COMPARE
                    </a>
                    <a class="dropdown-item nav__link asd-1" href="#">
                        LOGIN/REGISTER
                    </a>
                </div>

            </li>
            <li class="ds-menu nav-item">
                <a id="solda" class="dropdown-header nav__head2 asd-2head" style="z-index: 10;">
                    <span  class="nav__htext">CATEGORIES</span>
                </a>
                <div id="asd2" class="d-none" style="position: relative;bottom: 50px; z-index: 5;">
                    <a class=" dropdown-item  nav__link  asd-2">
                        <i class="icon-furniture"></i>FURNITURE
                    </a>
                    <a class="dropdown-item  nav__link  asd-2" href="#">
                        <i class="icon-lighting"></i>LIGHTING
                    </a>
                    <a class="dropdown-item nav__link  asd-2" href="#">
                        <i class="icon-accessories"></i>ACCESSORIES
                    </a>
                    <a class="dropdown-item nav__link asd-2" href="#">
                        <i class="icon-toys"></i>TOYS
                    </a>
                    <a class="dropdown-item nav__link asd-2" href="#">
                        <i class="icon-clocks"></i>CLOCKS
                    </a>
                    <a class="dropdown-item nav__link asd-2" href="#">
                        <i class="icon-cooking"></i> COOKING
                    </a>
                    <a class="dropdown-item nav__link asd-2" href="#">
                        <i class="icon-electronics"></i>ELECTRONICS
                    </a>
                    <a class="dropdown-item nav__link asd-2" href="#">
                        <i class="icon-minimalism"></i>MINIMALISM
                    </a>
                    <a class="dropdown-item nav__link asd-2" href="#">
                        <i class="icon-fashion"></i>FASHION
                    </a>
                </div>

            </li>
        </ul>

    </div>
    <div class="nav__overlay"></div>
</nav>
