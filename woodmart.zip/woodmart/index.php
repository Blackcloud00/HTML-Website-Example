<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>WoodMart – Responsive WooCommerce WordPress Theme</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.css" />
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
    <link rel="stylesheet" href="assets/scss/style.css">
    <link rel="stylesheet" href="assets/scss/slider.css">
    <link rel="stylesheet" href="assets/scss/reset.css">
    <link rel="stylesheet" href="assets/scss/mobil-menu.css">
    <link rel="stylesheet" href="assets/webfw/css/fontawesome-all.css">

</head>
<body class="preload">
<div class="web_section">
    <header class="web_header">
        <nav class="navbar navbar-1 navbar-expand-lg">
            <div class="container">
                <div class="collapse navbar-collapse" id="navbarScroll">
                    <ul class="navbar-nav  my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
                        <li class="nav-item   web-right dropdown menu-1 english">
                            <a class="nav-link" href="#" id="navbarScrollingDropdown" role="button"
                               data-bs-toggle="dropdown" aria-expanded="false">ENGLISH<i
                                        class="icon-down-arrow"></i></a>
                            <ul class="dropdown-menu" aria-labelledby="navbarScrollingDropdown">
                                <li><a class="web-junior dropdown-item" href="#">Deutsch</a></li>
                                <li><a class="web-junior dropdown-item" href="#">French</a></li>
                                <li><a class="web-junior dropdown-item" href="#">Requires WPML plugin</a></li>
                            </ul>
                        </li>
                        <li class="nav-item  web-right dropdown menu-1 country">
                            <a class="nav-link" href="#" id="navbarScrollingDropdown" role="button"
                               data-bs-toggle="dropdown" aria-expanded="false">COUNTRY<i
                                        class="icon-down-arrow"></i></a>
                            <ul class="dropdown-menu" aria-labelledby="navbarScrollingDropdown">
                                <li><a class="web-junior dropdown-item" href="#">United States (USD)</a></li>
                                <li><a class="web-junior dropdown-item" href="#">Deutschland (EUR)</a></li>
                                <li><a class="web-junior dropdown-item" href="#">Japan (JPY)</a></li>
                            </ul>
                        </li>
                    </ul>
                    <div class="header_text">
                        <strong>
                            <span style="color: #ffffff;font-size: 12px;padding-left: 11px;position: relative;bottom: 2px;">FREE SHIPPING FOR ALL ORDERS OF $150</span>
                        </strong>
                    </div>

                </div>
                <div class="navbar end menu-center">
                    <ul class="navbar-nav menu-content ">
                        <li class="nav-item social-media"><i class="icon-facebook"></i></li>
                        <li class="nav-item social-media"><i class="icon-twitter"></i></li>
                        <li class="nav-item social-media"><i class="icon-letter_1"
                                                             style="position: relative;top: 3px;"></i></li>
                        <li class="nav-item social-media"><i class="icon-instagram"></i></li>
                        <li class="nav-item social-media"><i class="icon-youtube"
                                                             style="position: relative;top: 3px;"></i></li>
                        <li class="nav-item social-media"><i class="icon-pinterest-social-logo"></i></li>
                    </ul>
                    <ul class="navbar-nav menu-none">
                        <li class="nav-item  web-left newsletter"><a href="" class="nav-link"><i class="icon-letter"
                                                                                                 style="position: relative;top: 3px; font-size: 14px;
font-weight: 500;padding-right: 6px;"></i>NEWSLETTER</a></li>
                        <li class="nav-item web-left contact-us"><a href="" class="nav-link">CONTACT US</a></li>
                        <li class="nav-item web-left faqs"><a href="" class="nav-link">FAQS</a></li>
                    </ul>
                </div>

            </div>
        </nav>
        <nav class="navbar navbar-2">
            <div class="container ">
                <div class="col-xl-3 col-lg-3 baslikus">
                    <a class="navbar-brand" href="#">
                        <img src="https://z9d7c4u6.rocketcdn.me/wp-content/themes/woodmart/images/wood-logo-dark.svg"
                             width="370" height="50" class="d-inline-block align-top" alt="WoodMart">
                    </a>
                </div>
                <div class="col-xl-6 col-lg-5 search-engine">
                    <div class="box">
                        <form>
                            <input type="text" placeholder="Search for products">
                            <select>
                                <option class="opt">SELECT CATEGORY</option>
                                <option class="opt">Clock</option>
                                <option class="opt">Lighting</option>
                                <option class="opt">Furniture</option>
                                <option class="opt">Accessories</option>
                                <option class="opt">Cooking</option>
                                <option class="opt">Toys</option>
                                <option class="opt">Other</option>
                            </select>
                            <button type="submit"><i class="icon-search"></i></button>
                        </form>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 iconiun">
                    <a class="login_link" href="#">LOGIN / REGISTER</a>
                    <div class="icon">
                        <i class="icon-heart" style="top: 3px; position: relative;"></i>
                        <i class="icon-shuffle"></i>
                        <i class="icon-shopping-bag"></i>
                        <span>$0.00</span>
                    </div>
                </div>
            </div>
        </nav>
        <?php require 'mobil-menu.php' ?>
        <nav class="navbar navbar-4 navbar-expand-lg">
            <div class="container">
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav" style="z-index: 10;">
                        <li class="ds-menu nav-item active">
                            <h6 class="dropdown-header ds-cuk ds-header"><i class="icon-list"></i><span class="ds-subject">BROWSE CATEGORIES</span><i
                                        class="icon-down-arrow"></i></h6>
                            <a class="dropdown-item ds-cuk " href="#"><i class="icon-furniture ds-icuk"></i>Furniture <i
                                        class="icon-right-arrow ds-icukus"></i></a>
                            <a class="dropdown-item ds-cuk " href="#"><i class="icon-cooking ds-icuk"></i>Cooking <i
                                        class="icon-right-arrow ds-icukus"></i></a>
                            <a class="dropdown-item ds-cuk" href="#"><i class="icon-accessories ds-icuk"></i>Accessories <i
                                        class="icon-right-arrow ds-icukus"></i></a>
                            <a class="dropdown-item ds-cuk " href="#"><i class="icon-fashion ds-icuk"></i>Fashion <i
                                        class="icon-right-arrow ds-icukus"></i></a>
                            <a class="dropdown-item ds-cuk" href="#"><i class="icon-clocks ds-icuk"></i>Clocks <i
                                        class="icon-right-arrow ds-icukus"></i></a>
                            <a class="dropdown-item ds-cuk" href="#"><i class="icon-lighting ds-icuk"></i>Lighting <i
                                        class="icon-right-arrow ds-icukus"></i></a>
                            <a class="dropdown-item ds-cuk" href="#"><i class="icon-toys ds-icuk"></i>Toys <i
                                        class="icon-right-arrow ds-icukus"></i></a>
                            <a class="dropdown-item ds-cuk" href="#"><i class="icon-frying-pan ds-icuk"></i>Hand Made</a>
                            <a class="dropdown-item ds-cuk" href="#"><i class="icon-electronics ds-icuk"></i>Electronics</a>
                            <a class="dropdown-item ds-cuk" href="#"><i class="icon-disc-brake ds-icuk"></i>Cars</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link ds-link active" href="#">HOME <i class="icon-down-arrow ds-icon"></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link ds-link" href="#">SHOP <i class="icon-down-arrow ds-icon"></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link ds-link" href="#">PAGES <i class="icon-down-arrow ds-icon"></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link ds-link" href="#">ELEMENTS <i class="icon-down-arrow ds-icon"></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link ds-link" href="#">BUY</a>
                        </li>
                    </ul>
                </div>
                <a href="" class="navbar-brand my-2 my-sm-0 ds-low low-1">SPECIAL OFFER</a>
                <a href="" class="navbar-brand my-2 my-sm-0 ds-low low-2">PURCHASE THEME</a>
            </div>
        </nav>
        <?php require 'slider.php' ?>
    </header>
</div>




<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"
        integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG"
        crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js"
        integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc"
        crossorigin="anonymous"></script>
<script src="assets/js/mobil_menu.js"></script>
<script src="assets/js/slider.js"></script>
<!-- Swiper JS -->
<script src="https://unpkg.com/swiper/swiper-bundle.js"></script>
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<!-- Initialize Swiper -->
<script>
    var swiper = new Swiper('.swiper-container', {
        spaceBetween: 30,
        effect: 'fade',
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
    });
</script>


</body>
</html>