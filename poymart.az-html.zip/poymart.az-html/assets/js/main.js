 const minHei = function () {
  //var hei = $("header>.header").innerHeight();
  var hei = 25;
  var sc = window.pageYOffset;
  var html = document.querySelector("html");
  if (sc >= hei) {
    if (!html.classList.contains('miniHeader')) html.classList.add('miniHeader');
  } else {
    if (html.classList.contains('miniHeader')) html.classList.remove('miniHeader');
  }
}
//var menuAc = document.querySelector(".menuAc");
 function classEkle() {
   var html = document.querySelector("html");
   if (html.classList.contains("openMenu")) {
     html.classList.remove("openMenu");
   } else {
     html.classList.add("openMenu");
   }
 }

 function popUpClass() {
   var html = document.querySelector("html");
   if (html.classList.contains("popupOpen")) {
     html.classList.remove("popupOpen");
   } else {
     html.classList.add("popupOpen");
   }
 }
/*$(window).scroll(function () {
  minHei();
});*/
 window.addEventListener('scroll', function() {
   minHei();
 });

 document.addEventListener("DOMContentLoaded", function(event) {
   document.querySelector(".menuAc").onclick = function() {classEkle()};
   document.querySelector(".kapatmaButton").onclick = function() {popUpClass()};
   document.querySelector(".etrafliBtn").onclick = function() {popUpClass()};
   document.getElementById("menuClose").onclick = function() {classEkle()};
 });
